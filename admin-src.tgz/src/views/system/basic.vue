<template>
  <div class="enterprise-setting-page" v-loading="loading">
    <!-- ========== 页面头部（大厂标准） ========== -->
    <header class="page-header">
      <div class="header-left">
        <h1 class="page-title">系统设置</h1>
        <p class="page-subtitle">配置小程序基础信息、支付参数、功能模块及通知模板</p>
      </div>
      <div class="header-right">
        <el-button @click="fetchConfig">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <el-button type="primary" :loading="savingAll" @click="handleSaveAll">
          {{ savingAll ? '保存中...' : '保存全部' }}
        </el-button>
      </div>
    </header>

    <!-- ========== 主内容区：Tab标签式布局（参考阿里云/腾讯云） ========== -->
    <main class="main-content">
      <el-tabs v-model="activeTab" type="border-card" class="setting-tabs">

        <!-- ==================== Tab 1: 基础配置 ==================== -->
        <el-tab-pane label="基础配置" name="basic">
          <div class="tab-content">

            <!-- 品牌基础信息（登录半屏 / 分享 / 导航同步） -->
            <div class="config-section">
              <div class="section-header">
                <h3 class="section-title">品牌基础信息</h3>
                <span class="section-desc">配置小程序名称、Logo 与登录半屏文案；保存后体验版/真机自动同步，未配置时使用默认值</span>
              </div>

              <el-form ref="brandFormRef" :model="miniProgramForm" :rules="brandRules" label-width="120px" label-position="left" class="compact-form">
                <div class="form-grid-2col">
                  <el-form-item label="小程序名称" prop="appName">
                    <el-input v-model="miniProgramForm.appName" placeholder="如：出海笔记" clearable />
                  </el-form-item>

                  <el-form-item label="文字 Logo">
                    <el-input v-model="miniProgramForm.logoMark" maxlength="4" placeholder="无图片时显示，如：海" clearable />
                  </el-form-item>
                </div>

                <el-form-item label="Logo 图片">
                  <div class="logo-uploader">
                    <div class="logo-preview-box" :class="{ 'is-empty': !logoPreviewDisplay }">
                      <img
                        v-if="logoPreviewUrl && !logoImageBroken"
                        :src="logoPreviewUrl"
                        alt="Logo预览"
                        @error="logoImageBroken = true"
                      />
                      <span v-else class="logo-preview-placeholder">{{ miniProgramForm.logoMark || '预览' }}</span>
                    </div>
                    <el-input v-model="miniProgramForm.logoUrl" placeholder="Logo URL 或点击上传" clearable class="logo-input" />
                    <div class="upload-btns">
                      <el-upload :show-file-list="false" :before-upload="beforeImageUpload" :http-request="handleLogoUpload" accept="image/*">
                        <el-button>上传</el-button>
                      </el-upload>
                      <el-button @click="handlePickAsset">素材库</el-button>
                    </div>
                  </div>
                </el-form-item>

                <div class="form-grid-2col">
                  <el-form-item label="登录副标题">
                    <el-input
                      v-model="miniProgramForm.loginTagline"
                      placeholder="如：想认识一下你，可以吗？"
                      maxlength="40"
                      show-word-limit
                      clearable
                    />
                  </el-form-item>

                  <el-form-item label="英文副标">
                    <el-input
                      v-model="miniProgramForm.brandEyebrow"
                      placeholder="如：CROSS-BORDER NOTES"
                      maxlength="40"
                      show-word-limit
                      clearable
                    />
                  </el-form-item>
                </div>

                <el-form-item label="分享引导语">
                  <el-input v-model="miniProgramForm.shareGuide" placeholder="用户分享时显示的文案" maxlength="50" show-word-limit />
                </el-form-item>

                <div class="action-bar">
                  <span class="upload-hint">保存后立即同步到小程序登录页、半屏登录与分享文案</span>
                  <el-button type="primary" size="small" :loading="brandSaving" @click="handleSaveBrandConfig">
                    {{ brandSaving ? '保存中...' : '保存品牌信息' }}
                  </el-button>
                </div>
              </el-form>
            </div>

            <!-- 微信小程序凭证 -->
            <div class="config-section section-spacing">
              <div class="section-header">
                <h3 class="section-title">微信小程序配置</h3>
                <span class="section-desc">小程序 AppID、AppSecret 与代码上传密钥</span>
              </div>

              <el-form ref="miniFormRef" :model="miniProgramForm" :rules="miniRules" label-width="120px" label-position="left" class="compact-form">
                <div class="form-grid-2col">
                  <el-form-item label="原始ID">
                    <el-input v-model="miniProgramForm.originalId" placeholder="gh_xxxxxxxxxxxx" clearable />
                  </el-form-item>

                  <el-form-item label="小程序 AppID" prop="appId">
                    <el-input v-model="miniProgramForm.appId" placeholder="wx1234567890abcdef" clearable />
                  </el-form-item>
                </div>

                <div class="form-grid-2col">
                  <el-form-item label="小程序 AppSecret" prop="appSecret">
                    <el-input v-model="miniProgramForm.appSecret" type="password" show-password placeholder="请输入AppSecret" />
                  </el-form-item>
                </div>

                <el-form-item label="代码上传密钥">
                  <el-input
                    v-model="miniProgramForm.uploadKey"
                    type="textarea"
                    :rows="3"
                    placeholder="粘贴微信小程序后台下载的代码上传密钥，用于「推送体验版」"
                  />
                </el-form-item>

                <el-form-item label="客服电话">
                  <el-input v-model="legalForm.servicePhone" placeholder="小程序「联系客服」拨号号码" clearable />
                </el-form-item>
                <el-form-item label="隐私政策外链">
                  <el-input v-model="legalForm.privacyPolicyUrl" placeholder="https://（可选，需配置业务域名）" clearable />
                </el-form-item>
                <el-form-item label="用户协议外链">
                  <el-input v-model="legalForm.userAgreementUrl" placeholder="https://（可选）" clearable />
                </el-form-item>

                <div class="action-bar">
                  <span class="upload-hint">
                    {{ uploadKeyStored ? '上传密钥已写入服务器' : '填写代码上传密钥后，请点击右侧按钮保存到服务器' }}
                    <template v-if="isLocalAdmin">（当前为本地后台，配置保存在本机数据库）</template>
                  </span>
                  <el-button type="primary" size="small" :loading="miniSaving" @click="handleSaveMiniProgram">
                    {{ miniSaving ? '保存中...' : '保存小程序配置' }}
                  </el-button>
                </div>
              </el-form>
            </div>

            <!-- 微信公众号（内容同步） -->
            <div class="config-section section-spacing">
              <div class="section-header">
                <h3 class="section-title">微信公众号配置</h3>
                <span class="section-desc">内容管理 → 同步导入 → 公众号全量导入</span>
              </div>
              <el-alert
                title="用于从认证服务号拉取已发布图文。同主体可留空，将回退使用上方小程序 AppID/AppSecret。"
                type="info"
                :closable="false"
                show-icon
                style="margin-bottom: 16px"
              />
              <el-form label-width="120px" label-position="left" class="compact-form">
                <div class="form-grid-2col">
                  <el-form-item label="公众号 AppID">
                    <el-input v-model="oaFormData.oaAppId" placeholder="留空则使用小程序 AppID" clearable />
                  </el-form-item>
                  <el-form-item label="公众号 AppSecret">
                    <el-input
                      v-model="oaFormData.oaAppSecret"
                      type="password"
                      show-password
                      placeholder="留空则使用小程序 AppSecret"
                      clearable
                    />
                  </el-form-item>
                </div>
                <div class="action-bar">
                  <span class="upload-hint">需已认证的微信服务号；订阅号无法使用全量导入接口</span>
                  <el-button type="primary" size="small" :loading="oaSaving" @click="handleSaveOa">
                    {{ oaSaving ? '保存中...' : '保存公众号配置' }}
                  </el-button>
                </div>
              </el-form>
            </div>

            <!-- 微信支付配置卡片 -->
            <div class="config-section section-spacing">
              <div class="section-header">
                <h3 class="section-title">微信支付配置</h3>
                <span class="section-desc">支持沙盒测试与生产环境切换</span>
                <el-switch v-model="paymentForm.enablePayment" active-text="已启用" inactive-text="未启用" class="enable-switch" />
              </div>

              <el-form v-if="paymentForm.enablePayment" ref="payFormRef" :model="paymentForm" :rules="paymentRules" label-width="110px" label-position="left" class="compact-form">
                <div class="env-toggle">
                  <span class="toggle-label">运行环境</span>
                  <el-radio-group v-model="paymentForm.payEnv" size="small">
                    <el-radio-button value="sandbox">沙盒环境</el-radio-button>
                    <el-radio-button value="production">生产环境</el-radio-button>
                  </el-radio-group>
                  <el-tag :type="paymentForm.payEnv === 'production' ? 'danger' : 'warning'" size="small" effect="light">
                    {{ paymentForm.payEnv === 'production' ? '正式收款' : '仅测试' }}
                  </el-tag>
                </div>

                <div class="form-grid-3col">
                  <el-form-item label="商户号" prop="mchId">
                    <el-input v-model="paymentForm.mchId" placeholder="微信支付商户号" clearable />
                  </el-form-item>

                  <el-form-item label="APIv3密钥">
                    <el-input v-model="paymentForm.apiV3Key" type="password" show-password placeholder="32位字符串" />
                  </el-form-item>

                  <el-form-item label="证书序列号">
                    <el-input v-model="paymentForm.certSerialNo" placeholder="7E**************" clearable />
                  </el-form-item>
                </div>

                <div class="form-grid-2col">
                  <el-form-item label="支付回调地址">
                    <el-input v-model="paymentForm.paymentNotifyUrl" placeholder="https://api.example.com/pay/notify" clearable />
                  </el-form-item>

                  <el-form-item label="退款回调地址">
                    <el-input v-model="paymentForm.refundNotifyUrl" placeholder="https://api.example.com/refund/notify" clearable />
                  </el-form-item>
                </div>

                <el-form-item label="商户API私钥">
                  <div class="cert-upload-row">
                    <el-upload :show-file-list="false" :before-upload="beforeCertUpload" :http-request="handleCertUpload" accept=".p12,.pem,.key">
                      <el-button icon="Upload" size="small">上传私钥文件</el-button>
                    </el-upload>
                    <span class="upload-hint">支持 apiclient_key.pem/.key，或密码为商户号的 .p12</span>
                    <el-tag v-if="paymentForm.certUploaded" type="success" size="small" effect="light">
                      <el-icon><CircleCheck /></el-icon> 已上传
                    </el-tag>
                  </div>
                </el-form-item>

                <div class="action-bar">
                  <el-button icon="MagicStick" size="small" :loading="payTesting" @click="handleTestPay">
                    {{ payTesting ? '验证中...' : '验证支付配置' }}
                  </el-button>
                  <el-button type="primary" size="small" :loading="paySaving" :class="{ 'btn-saved': paySaved }" @click="handleSavePayment">
                    {{ paySaved ? '✓ 已保存' : '保存支付配置' }}
                  </el-button>
                </div>
              </el-form>
            </div>

          </div>
        </el-tab-pane>

        <!-- ==================== Tab 2: 功能模块 ==================== -->
        <el-tab-pane label="功能模块" name="modules">
          <div class="tab-content">

            <!-- 模块分组：按业务场景分类 -->
            <div class="module-groups">

              <!-- 分组1: 核心交易模块 -->
              <div class="module-group">
                <div class="group-header">
                  <h4 class="group-title">
                    <el-icon><ShoppingCart /></el-icon>
                    核心交易模块
                  </h4>
                  <span class="group-desc">商品售卖与订单管理相关</span>
                </div>
                <div class="module-cards">
                  <div v-for="plugin in coreModules" :key="plugin.key" class="module-card" :class="{ disabled: !plugin.enabled }">
                    <div class="card-left">
                      <div class="card-icon">{{ plugin.icon }}</div>
                      <div class="card-info">
                        <div class="card-name">{{ plugin.name }}</div>
                        <div class="card-desc">{{ plugin.desc }}</div>
                      </div>
                    </div>
                    <el-switch v-model="plugin.enabled" inline-prompt active-text="开" inactive-text="关" @change="(val) => onModuleToggle(plugin, val)" />
                  </div>
                </div>
              </div>

              <!-- 分组2: 内容与互动模块 -->
              <div class="module-group">
                <div class="group-header">
                  <h4 class="group-title">
                    <el-icon><Document /></el-icon>
                    内容与互动模块
                  </h4>
                  <span class="group-desc">内容发布、活动运营及用户互动</span>
                </div>
                <div class="module-cards">
                  <div v-for="plugin in contentModules" :key="plugin.key" class="module-card" :class="{ disabled: !plugin.enabled }">
                    <div class="card-left">
                      <div class="card-icon">{{ plugin.icon }}</div>
                      <div class="card-info">
                        <div class="card-name">{{ plugin.name }}</div>
                        <div class="card-desc">{{ plugin.desc }}</div>
                      </div>
                    </div>
                    <el-switch v-model="plugin.enabled" inline-prompt active-text="开" inactive-text="关" @change="(val) => onModuleToggle(plugin, val)" />
                  </div>
                </div>
              </div>

              <!-- 分组3: 营销与增长模块 -->
              <div class="module-group">
                <div class="group-header">
                  <h4 class="group-title">
                    <el-icon><Promotion /></el-icon>
                    营销与增长模块
                  </h4>
                  <span class="group-desc">优惠券、会员体系及智能推荐</span>
                </div>
                <div class="module-cards">
                  <div v-for="plugin in marketingModules" :key="plugin.key" class="module-card" :class="{ disabled: !plugin.enabled }">
                    <div class="card-left">
                      <div class="card-icon">{{ plugin.icon }}</div>
                      <div class="card-info">
                        <div class="card-name">{{ plugin.name }}</div>
                        <div class="card-desc">{{ plugin.desc }}</div>
                      </div>
                    </div>
                    <el-switch v-model="plugin.enabled" inline-prompt active-text="开" inactive-text="关" @change="(val) => onModuleToggle(plugin, val)" />
                  </div>
                </div>
              </div>

            </div>

            <div class="action-bar action-bar-center">
              <el-button type="primary" :loading="pluginSaving" :class="{ 'btn-saved': pluginSaved }" @click="handleSavePlugins">
                {{ pluginSaved ? '✓ 已保存模块配置' : '保存模块设置' }}
              </el-button>
            </div>

          </div>
        </el-tab-pane>

        <!-- ==================== Tab 3: 物流配送 ==================== -->
        <el-tab-pane label="物流配送" name="logistics">
          <div class="tab-content">

            <div class="config-section">
              <div class="section-header">
                <h3 class="section-title">物流平台授权</h3>
                <span class="section-desc">对接第三方物流服务，实现自动查询与发货</span>
              </div>

              <el-form :model="logisticsForm" label-width="100px" label-position="left" class="compact-form">
                <div class="form-grid-2col">
                  <el-form-item label="物流平台">
                    <el-select v-model="logisticsForm.platform" placeholder="选择物流服务商">
                      <el-option label="顺丰速运 SDK" value="sf" />
                      <el-option label="菜鸟裹裹 API" value="cainiao" />
                      <el-option label="快递100" value="kuaidi100" />
                      <el-option label="京东物流" value="jd" />
                    </el-select>
                  </el-form-item>

                  <el-form-item label="AppKey">
                    <el-input v-model="logisticsForm.appKey" type="password" show-password placeholder="物流平台密钥" />
                  </el-form-item>
                </div>

                <el-form-item label="默认仓库地址">
                  <el-input v-model="logisticsForm.defaultAddress" type="textarea" :rows="2" placeholder="默认发货仓库的详细地址" />
                </el-form-item>
              </el-form>
            </div>

            <!-- 运费模板列表 -->
            <div class="config-section section-spacing freight-template-section">
              <div class="section-header">
                <h3 class="section-title">运费模板管理</h3>
                <span class="section-desc">按配送区域设置首件/续件或首重/续重运费，支持指定条件包邮</span>
              </div>

              <div class="toolbar">
                <span class="toolbar-meta">共 {{ freightTemplates.length }} 个模板</span>
                <div class="toolbar-spacer" />
                <el-button type="primary" :icon="Plus" @click="openFreightDialog()">新建模板</el-button>
              </div>

              <div v-if="!freightTemplates.length" class="table-panel empty-panel">
                暂无运费模板，请点击「新建模板」
              </div>
              <div v-else class="table-panel">
                <el-table :data="freightTemplates" stripe style="width: 100%">
                  <el-table-column label="模板名称" min-width="168" show-overflow-tooltip>
                    <template #default="{ row }">
                      <div class="freight-name-cell">
                        <span class="freight-name">{{ row.name }}</span>
                        <span v-if="row.remark" class="freight-remark">{{ row.remark }}</span>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column label="计费方式" width="100" align="center">
                    <template #default="{ row }">
                      <el-tag
                        :type="row.billingMethod === 'free' ? 'success' : row.billingMethod === 'weight' ? 'warning' : 'info'"
                        size="small"
                        effect="plain"
                      >
                        {{ billingMethodLabel(row.billingMethod) }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column label="配送区域" min-width="180" show-overflow-tooltip>
                    <template #default="{ row }">
                      {{ regionRulesSummary(row.regionRules) }}
                    </template>
                  </el-table-column>
                  <el-table-column label="条件包邮" width="120" align="center">
                    <template #default="{ row }">
                      <span class="freight-free-summary">{{ freeRuleSummary(row.freeRule) }}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="默认" width="72" align="center">
                    <template #default="{ row }">
                      <el-tag v-if="row.isDefault" type="primary" size="small" effect="plain">默认</el-tag>
                      <span v-else class="text-muted">-</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="状态" width="92" align="center">
                    <template #default="{ row }">
                      <el-tag :type="row.status === 'active' ? 'success' : 'info'" size="small" effect="plain">
                        {{ row.status === 'active' ? '使用中' : '已停用' }}
                      </el-tag>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" min-width="140">
                    <template #default="{ row }">
                      <el-button link type="primary" size="small" @click="openFreightDialog(row)">编辑</el-button>
                      <el-button link type="danger" size="small" @click="handleDeleteFreightTemplate(row)">删除</el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </div>

            <div class="action-bar">
              <el-button type="primary" :loading="logisticsSaving" :class="{ 'btn-saved': logisticsSaved }" @click="handleSaveLogistics">
                {{ logisticsSaved ? '✓ 已保存' : '保存物流配置' }}
              </el-button>
            </div>

          </div>
        </el-tab-pane>

        <!-- ==================== Tab 4: 权限角色 ==================== -->
        <el-tab-pane label="权限角色" name="roles">
          <div class="tab-content">

            <div class="config-section role-section">
              <div class="section-header">
                <h3 class="section-title">角色权限矩阵</h3>
                <span class="section-desc">定义不同角色的功能访问范围（保存全部时一并写入配置）</span>
              </div>

              <div class="toolbar">
                <span class="toolbar-meta">共 {{ roleList.length }} 个角色</span>
                <div class="toolbar-spacer" />
                <el-button type="primary" :icon="Plus" @click="openRoleDialog()">新建角色</el-button>
              </div>

              <div class="role-matrix">
                <div v-for="role in roleList" :key="role.id" class="role-card-enterprise">
                  <div class="role-main">
                    <div class="role-avatar">{{ role.icon }}</div>
                    <div class="role-detail">
                      <div class="role-meta">
                        <strong class="role-name">{{ role.name }}</strong>
                        <el-tag v-if="role.tag" type="danger" size="small" effect="dark" round>{{ role.tag }}</el-tag>
                      </div>
                      <p class="role-desc">{{ role.desc }}</p>
                    </div>
                  </div>
                  <div class="role-perms">
                    <el-tag v-for="perm in role.permissions" :key="perm" size="small" effect="plain" round>{{ perm }}</el-tag>
                  </div>
                  <div class="role-actions">
                    <el-button link type="primary" size="small" @click="openRoleDialog(role)">编辑权限</el-button>
                    <el-button
                      link
                      type="danger"
                      size="small"
                      :disabled="role.builtIn"
                      @click="handleDeleteRole(role)"
                    >
                      删除角色
                    </el-button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </el-tab-pane>

        <!-- ==================== Tab 5: 订阅消息 ==================== -->
        <el-tab-pane label="订阅消息" name="notifications">
          <div class="tab-content">

            <div class="config-section">
              <div class="section-header">
                <h3 class="section-title">消息模板配置</h3>
                <span class="section-desc">配置微信服务通知模板ID，用于关键节点提醒</span>
                <div class="header-actions">
                  <el-button size="small" icon="Document" @click="handleGetTemplateId">获取模板ID</el-button>
                  <el-button type="primary" size="small" :loading="notificationSaving" :class="{ 'btn-saved': notificationSaved }" @click="handleSaveNotifications">
                    {{ notificationSaved ? '✓ 已保存' : '保存通知配置' }}
                  </el-button>
                </div>
              </div>

              <el-table :data="notificationList" border stripe class="data-table">
                <el-table-column label="通知场景" min-width="200">
                  <template #default="{ row }">
                    <div class="scene-cell">
                      <span class="scene-icon">{{ row.scene.split(' ')[0] }}</span>
                      <span class="scene-text">{{ row.scene.split(' ').slice(1).join(' ') }}</span>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column label="微信模板ID" min-width="220">
                  <template #default="{ row }">
                    <el-input v-model="row.templateId" placeholder="请输入模板ID" size="small" clearable />
                  </template>
                </el-table-column>
                <el-table-column prop="trigger" label="触发时机" min-width="180" />
                <el-table-column label="状态" width="100" align="center">
                  <template #default="{ row }">
                    <el-tag :type="row.templateId ? 'success' : 'info'" size="small" effect="dark" round>
                      {{ row.templateId ? '已配置' : '待配置' }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="操作" width="100" align="center">
                  <template #default="{ row }">
                    <el-button link type="primary" size="small" :disabled="!row.templateId" @click="handleTestNotification(row)">测试发送</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>

          </div>
        </el-tab-pane>

      </el-tabs>
    </main>

    <FreightTemplateEditorDialog
      v-model:visible="freightDialogVisible"
      :template="freightEditingTemplate"
      @save="handleFreightSave"
    />

    <el-dialog
      v-model="roleDialogVisible"
      :title="roleEditingId ? '编辑角色' : '新建角色'"
      width="560px"
      append-to-body
      :close-on-click-modal="false"
      destroy-on-close
      @closed="resetRoleForm"
    >
      <el-form ref="roleFormRef" :model="roleForm" :rules="roleFormRules" label-width="88px">
        <el-form-item label="角色图标">
          <div class="role-icon-field">
            <el-popover v-model:visible="roleIconPopoverVisible" placement="bottom-start" :width="288" trigger="click">
              <template #reference>
                <button type="button" class="role-icon-trigger" title="点击从图标库选择">
                  {{ roleForm.icon || '👤' }}
                </button>
              </template>
              <div class="role-icon-library">
                <button
                  v-for="emoji in ROLE_ICON_LIBRARY"
                  :key="emoji"
                  type="button"
                  class="role-icon-option"
                  :class="{ active: roleForm.icon === emoji }"
                  @click="selectRoleIcon(emoji)"
                >
                  {{ emoji }}
                </button>
              </div>
            </el-popover>
            <span class="role-icon-hint">点击左侧图标打开库，选中即可</span>
          </div>
        </el-form-item>
        <el-form-item label="角色名称" prop="name">
          <el-input v-model="roleForm.name" maxlength="20" show-word-limit placeholder="如：内容运营" />
        </el-form-item>
        <el-form-item label="角色说明">
          <el-input v-model="roleForm.desc" type="textarea" :rows="2" maxlength="80" show-word-limit placeholder="简要描述职责" />
        </el-form-item>
        <el-form-item label="权限范围" prop="permissions">
          <el-checkbox-group v-model="roleForm.permissions" class="role-perm-checkboxes">
            <el-checkbox v-for="perm in PERMISSION_OPTIONS" :key="perm" :label="perm">{{ perm }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="roleDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitRole">保存</el-button>
      </template>
    </el-dialog>

    <AssetPickerDialog
      v-model="assetPickerVisible"
      @select="handleLogoAssetSelected"
    />

  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted, watch, nextTick } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules, UploadRequestOptions } from 'element-plus'
import { Refresh, CircleCheck, ShoppingCart, Document, Promotion, Plus } from '@element-plus/icons-vue'
import {
  getConfigsSilent,
  saveUploadKey,
  testWxPayConfig,
  updateConfigs,
  uploadFile,
  uploadWxPayPrivateKey,
  normalizeUploadUrl,
} from '@/api/system'
import {
  applyConfigListToForm,
  extractConfigList,
  hasStoredUploadKey,
  readConfigEntry,
  toConfigUpdateItems,
  type RawConfigItem,
} from '@/utils/system-config'
import {
  applyBrandConfigToForm,
  buildBrandConfigUpdateItems,
  normalizeBrandConfig,
} from '@/utils/brand-config'
import { DEFAULT_MINIAPP_BRAND_CONFIG } from '@/types/miniapp'
import {
  billingMethodLabel,
  freeRuleSummary,
  normalizeFreightTemplate,
  regionRulesSummary,
  type FreightTemplate,
} from '@/types/freight'
import AssetPickerDialog from '@/components/AssetPickerDialog.vue'

const loading = ref(false)
const savingAll = ref(false)
const miniSaving = ref(false)
const oaSaving = ref(false)
const brandSaving = ref(false)
const uploadKeyStored = ref(false)
const isLocalAdmin = computed(() => {
  const host = window.location.hostname
  return import.meta.env.DEV || host === 'localhost' || host === '127.0.0.1'
})
const paySaving = ref(false)
const payTesting = ref(false)
const paySaved = ref(false)
const pluginSaving = ref(false)
const pluginSaved = ref(false)
const logisticsSaving = ref(false)
const logisticsSaved = ref(false)
const notificationSaving = ref(false)
const notificationSaved = ref(false)
const allSaved = ref(false)
const miniSaved = ref(false)
const miniProgramSavedSnapshot = ref('')
const miniProgramSavedAt = ref('')
const miniFormRef = ref<FormInstance>()
const brandFormRef = ref<FormInstance>()
const payFormRef = ref<FormInstance>()
const assetPickerVisible = ref(false)
const logoImageBroken = ref(false)

// 当前激活的Tab
const activeTab = ref('basic')

// ==================== 表单数据接口 ====================

interface MiniProgramForm {
  appName: string
  appId: string
  appSecret: string
  uploadKey: string
  originalId: string
  logoUrl: string
  logoMark: string
  loginTagline: string
  brandEyebrow: string
  shareGuide: string
}

interface PaymentForm {
  enablePayment: boolean
  payEnv: 'sandbox' | 'production'
  mchId: string
  apiV3Key: string
  certSerialNo: string
  certUploaded: boolean
  paymentNotifyUrl: string
  refundNotifyUrl: string
}

interface LogisticsForm {
  platform: string
  appKey: string
  defaultAddress: string
}

interface LegalForm {
  privacyPolicyUrl: string
  userAgreementUrl: string
  servicePhone: string
}

interface PluginModule {
  key: string
  name: string
  desc: string
  icon: string
  enabled: boolean
}

interface NotificationItem {
  scene: string
  templateId: string
  trigger: string
}

interface RoleItem {
  id: string
  icon: string
  name: string
  desc: string
  tag?: string
  builtIn?: boolean
  permissions: string[]
}

const PERMISSION_OPTIONS = [
  '全部模块',
  '系统设置',
  '用户管理',
  '日志查看',
  '内容管理',
  '活动管理',
  '表单查看',
  '素材库',
  '商品管理',
  '订单管理',
  '营销工具',
  '会员查看',
  '财务管理',
  '智能 Agent',
]

const ROLE_ICON_LIBRARY = [
  '👤', '👑', '🛡️', '⭐', '🎯', '💼', '📝', '🛍️',
  '📦', '💰', '📊', '🎨', '🎬', '📚', '🎓', '🏥',
  '🤖', '💬', '📣', '🎟️', '📅', '📋', '🖼️', '🎵',
  '🏠', '🚗', '✈️', '🌐', '🔧', '⚙️', '🔑', '🧩',
  '✅', '❤️', '🔥', '💎', '🎁', '👥', '🧑‍💻', '👩‍💼',
]

// ==================== 响应式数据 ====================

const miniProgramForm = reactive<MiniProgramForm>({
  appName: DEFAULT_MINIAPP_BRAND_CONFIG.appName,
  appId: '',
  appSecret: '',
  uploadKey: '',
  originalId: '',
  logoUrl: DEFAULT_MINIAPP_BRAND_CONFIG.logoUrl,
  logoMark: DEFAULT_MINIAPP_BRAND_CONFIG.logoMark,
  loginTagline: DEFAULT_MINIAPP_BRAND_CONFIG.loginTagline,
  brandEyebrow: DEFAULT_MINIAPP_BRAND_CONFIG.brandEyebrow,
  shareGuide: '欢迎体验我们的品牌小程序',
})

const oaFormData = reactive({
  oaAppId: '',
  oaAppSecret: '',
})

const logoPreviewUrl = computed(() => {
  const raw = miniProgramForm.logoUrl?.trim()
  if (!raw) return ''
  const normalized = normalizeUploadUrl(raw)
  if (/^(https?:\/\/|data:)/i.test(normalized)) return normalized
  if (normalized.startsWith('/')) return `${window.location.origin}${normalized}`
  return normalized
})

const logoPreviewDisplay = computed(() => {
  if (logoPreviewUrl.value && !logoImageBroken.value) return logoPreviewUrl.value
  return miniProgramForm.logoMark?.trim() || ''
})

watch(
  () => miniProgramForm.logoUrl,
  () => {
    logoImageBroken.value = false
  },
)

const paymentForm = reactive<PaymentForm>({
  enablePayment: false,
  payEnv: 'sandbox',
  mchId: '',
  apiV3Key: '',
  certSerialNo: '',
  certUploaded: false,
  paymentNotifyUrl: 'https://api.zfculture.site/api/v1/mp/payments/wx-notify',
  refundNotifyUrl: 'https://api.zfculture.site/api/v1/mp/payments/wx-refund-notify',
})

const logisticsForm = reactive<LogisticsForm>({
  platform: 'sf',
  appKey: '',
  defaultAddress: '广东省深圳市南山区高新园区',
})

const legalForm = reactive<LegalForm>({
  privacyPolicyUrl: '',
  userAgreementUrl: '',
  servicePhone: '',
})

// 模块分组数据
const allPlugins = reactive<PluginModule[]>([
  { key: 'product', name: '商品模块', desc: '商品管理、订单处理、在线支付', icon: '🛍️', enabled: true },
  { key: 'member', name: '会员模块', desc: '等级体系、积分权益、会员卡', icon: '👥', enabled: true },
  { key: 'order', name: '订单模块', desc: '订单全流程管理与售后', icon: '📦', enabled: true },
])

const contentModules = reactive<PluginModule[]>([
  { key: 'content', name: '内容模块', desc: '文章发布、图文编辑、视频管理', icon: '📝', enabled: true },
  { key: 'activity', name: '活动模块', desc: '沙龙课程、展会报名、签到核销', icon: '🎉', enabled: true },
  { key: 'form', name: '表单模块', desc: '报名登记、咨询问卷、数据收集', icon: '📋', enabled: true },
  { key: 'appointment', name: '预约模块', desc: '服务预约、时间管理、到店核销', icon: '📅', enabled: true },
])

const marketingModules = reactive<PluginModule[]>([
  { key: 'coupon', name: '营销模块', desc: '优惠券发放、满减活动、兑换码', icon: '🎟️', enabled: true },
  { key: 'agent', name: '智能Agent', desc: 'AI推荐引擎、智能对话、数据分析', icon: '🤖', enabled: true },
])

// 合并所有模块用于保存
const pluginModules = computed(() => [...allPlugins, ...contentModules, ...marketingModules])

// 核心交易模块
const coreModules = allPlugins

// 运费模板数据
const freightTemplates = ref<FreightTemplate[]>([
  normalizeFreightTemplate({
    id: 'ft_default',
    name: '全国包邮模板',
    type: 'free',
    billingMethod: 'free',
    status: 'active',
    isDefault: true,
  }),
  normalizeFreightTemplate({
    id: 'ft_free',
    name: '数字商品免运费',
    type: 'free',
    billingMethod: 'free',
    status: 'active',
  }),
  normalizeFreightTemplate({
    id: 'ft_weight',
    name: '偏远地区加价',
    type: 'weight',
    billingMethod: 'weight',
    status: 'active',
    regionRules: [
      {
        id: 'rr_national',
        regionLabel: '默认地区',
        regions: ['全国'],
        firstUnit: 1,
        firstFee: 8,
        extraUnit: 1,
        extraFee: 3,
      },
      {
        id: 'rr_remote',
        regionLabel: '偏远地区',
        regions: ['新疆维吾尔自治区', '西藏自治区', '青海省', '内蒙古自治区', '甘肃省', '宁夏回族自治区'],
        firstUnit: 1,
        firstFee: 18,
        extraUnit: 1,
        extraFee: 8,
      },
    ],
    freeRule: { enabled: true, type: 'amount', threshold: 199 },
  }),
])

const freightDialogVisible = ref(false)
const freightEditingTemplate = ref<FreightTemplate | null>(null)

const notificationList = reactive<NotificationItem[]>([
  { scene: '📦 订单发货通知', templateId: 'OPENTM407913429', trigger: '填写运单后自动触发' },
  { scene: '✅ 报名成功通知', templateId: 'OPENTM814637211', trigger: '审核通过后推送' },
  { scene: '📅 预约提醒通知', templateId: 'OPENTM203748920', trigger: '预约前2小时触发' },
  { scene: '💰 支付成功确认', templateId: '', trigger: '支付回调后立即发送' },
  { scene: '🎟️ 优惠券到期提醒', templateId: '', trigger: '到期前3天定时推送' },
])

const roleList = reactive<RoleItem[]>([
  {
    id: 'role_super_admin',
    icon: '👑',
    name: '超级管理员',
    desc: '拥有全部功能权限，可管理系统配置',
    tag: '系统内置',
    builtIn: true,
    permissions: ['全部模块', '系统设置', '用户管理', '日志查看'],
  },
  {
    id: 'role_content',
    icon: '📝',
    name: '内容运营',
    desc: '负责内容发布、活动运营、表单管理',
    permissions: ['内容管理', '活动管理', '表单查看', '素材库'],
  },
  {
    id: 'role_business',
    icon: '🛍️',
    name: '商务运营',
    desc: '负责商品上架、订单处理、营销活动',
    permissions: ['商品管理', '订单管理', '营销工具', '会员查看'],
  },
])

const roleDialogVisible = ref(false)
const roleIconPopoverVisible = ref(false)
const roleEditingId = ref<string | null>(null)
const roleFormRef = ref<FormInstance>()
const roleForm = reactive({
  icon: '👤',
  name: '',
  desc: '',
  permissions: [] as string[],
})
const roleFormRules: FormRules = {
  name: [{ required: true, message: '请输入角色名称', trigger: 'blur' }],
  permissions: [{ type: 'array', required: true, min: 1, message: '请至少选择一项权限', trigger: 'change' }],
}

// ==================== 验证规则 ====================

const brandRules: FormRules = {
  appName: [{ required: true, message: '请输入小程序名称', trigger: 'blur' }],
}

const miniRules: FormRules = {
  appId: [{ required: true, message: '请输入AppID', trigger: 'blur' }],
}

const paymentRules: FormRules = {
  mchId: [{ required: true, message: '请输入商户号', trigger: 'blur' }],
}

// ==================== 工具函数 ====================

function getMiniProgramSnapshot() {
  return JSON.stringify({
    appName: miniProgramForm.appName,
    appId: miniProgramForm.appId,
    appSecret: miniProgramForm.appSecret,
    uploadKey: miniProgramForm.uploadKey,
    originalId: miniProgramForm.originalId,
    logoUrl: miniProgramForm.logoUrl,
    logoMark: miniProgramForm.logoMark,
    loginTagline: miniProgramForm.loginTagline,
    brandEyebrow: miniProgramForm.brandEyebrow,
    shareGuide: miniProgramForm.shareGuide,
  })
}

function markMiniProgramSaved() {
  miniProgramSavedSnapshot.value = getMiniProgramSnapshot()
  miniProgramSavedAt.value = new Date().toLocaleTimeString('zh-CN', { hour12: false })
}

const hasMiniProgramChanges = computed(() => {
  if (!miniProgramSavedSnapshot.value) return false
  return getMiniProgramSnapshot() !== miniProgramSavedSnapshot.value
})

const miniProgramSaveStatus = computed(() => {
  if (miniSaving.value) return '保存中...'
  if (hasMiniProgramChanges.value) return '有未保存更改'
  return miniProgramSavedAt.value ? `已保存 ${miniProgramSavedAt.value}` : '已保存'
})

// ==================== 数据加载 ====================

let dataLoaded = false

function applyPluginConfigs(configs: RawConfigItem[]) {
  configs.forEach((item) => {
    const { key, value } = readConfigEntry(item)
    if (key !== 'plugins' || !value) return
    try {
      const list = JSON.parse(value) as Array<{ key: string; enabled?: boolean }>
      if (!Array.isArray(list)) return
      list.forEach((entry) => {
        const plugin = pluginModules.value.find(p => p.key === entry.key)
        if (plugin) plugin.enabled = entry.enabled !== false
      })
    } catch {
      // ignore invalid json
    }
  })
}

function applyNotificationConfigs(configs: RawConfigItem[]) {
  configs.forEach((item) => {
    const { key, value } = readConfigEntry(item)
    if (key !== 'notifications' || !value) return
    try {
      const list = JSON.parse(value) as NotificationItem[]
      if (!Array.isArray(list) || !list.length) return
      notificationList.splice(0, notificationList.length, ...list)
    } catch {
      // ignore invalid json
    }
  })
}

function applyRoleConfigs(configs: RawConfigItem[]) {
  configs.forEach((item) => {
    const { key, value } = readConfigEntry(item)
    if (key !== 'roleMatrix' || !value) return
    try {
      const list = JSON.parse(value) as RoleItem[]
      if (!Array.isArray(list) || !list.length) return
      roleList.splice(0, roleList.length, ...list.map((role, index) => ({
        id: role.id || `role_${index}`,
        icon: role.icon || '👤',
        name: role.name,
        desc: role.desc || '',
        tag: role.tag,
        builtIn: !!role.builtIn,
        permissions: Array.isArray(role.permissions) ? [...role.permissions] : [],
      })))
    } catch {
      // ignore invalid json
    }
  })
}

function applyFreightConfigs(configs: RawConfigItem[]) {
  configs.forEach((item) => {
    const { key, value } = readConfigEntry(item)
    if (key !== 'freightTemplates' || !value) return
    try {
      const list = JSON.parse(value) as FreightTemplate[]
      if (!Array.isArray(list) || !list.length) return
      freightTemplates.value = list.map((entry, index) => normalizeFreightTemplate(entry, index))
    } catch {
      // ignore invalid json
    }
  })
}

function applyConfigs(configs: RawConfigItem[]) {
  applyConfigListToForm(configs, [
    miniProgramForm as unknown as Record<string, unknown>,
    oaFormData as unknown as Record<string, unknown>,
    paymentForm as unknown as Record<string, unknown>,
    logisticsForm as unknown as Record<string, unknown>,
    legalForm as unknown as Record<string, unknown>,
  ])
  applyPluginConfigs(configs)
  applyNotificationConfigs(configs)
  applyFreightConfigs(configs)
  applyRoleConfigs(configs)
  // 品牌 JSON 需在 flat 字段（site_logo/site_name）之后应用，避免被旧值覆盖
  applyBrandConfigToForm(configs, miniProgramForm)
  if (miniProgramForm.logoUrl) {
    miniProgramForm.logoUrl = normalizeUploadUrl(miniProgramForm.logoUrl)
  }
}

function buildBrandSaveItems() {
  const brand = normalizeBrandConfig(miniProgramForm)
  const items = buildBrandConfigUpdateItems(brand)
  if (miniProgramForm.shareGuide?.trim()) {
    items.push({
      configKey: 'miniappShareTitle',
      configValue: miniProgramForm.shareGuide.trim(),
      configGroup: 'basic',
      description: '分享引导语',
    })
  }
  return items
}

function pickWechatFormPayload() {
  return {
    appId: miniProgramForm.appId,
    appSecret: miniProgramForm.appSecret,
    originalId: miniProgramForm.originalId,
    uploadKey: miniProgramForm.uploadKey,
  }
}

function pickOaFormPayload() {
  return {
    oaAppId: oaFormData.oaAppId,
    oaAppSecret: oaFormData.oaAppSecret,
  }
}

function buildLogisticsPayload(): Record<string, unknown> {
  return {
    ...(logisticsForm as unknown as Record<string, unknown>),
    freightTemplates: freightTemplates.value,
  }
}

async function fetchConfig() {
  loading.value = true
  try {
    const res = await getConfigsSilent()
    const configList = extractConfigList(res.data)
    applyConfigs(configList)
    uploadKeyStored.value = hasStoredUploadKey(configList)

    markMiniProgramSaved()
    await nextTick()
    markAllAsConfigured()
    dataLoaded = true
  } catch (e) {
    console.error('配置加载异常:', e)
    dataLoaded = true
  } finally {
    loading.value = false
  }
}

function markAllAsConfigured() {
  paySaved.value = !!(paymentForm.mchId?.trim() || paymentForm.apiV3Key?.trim())
  pluginSaved.value = true
  logisticsSaved.value = true
  notificationSaved.value = true
  allSaved.value = true
}

function toConfigItems(data: Record<string, unknown>, group: string) {
  return toConfigUpdateItems(data, group)
}

async function saveGroup(group: string, _label: string, data: Record<string, unknown>) {
  await updateConfigs(toConfigItems(data, group))
}

// ==================== 事件处理 ====================

async function handleSaveAll() {
  const brandValid = await brandFormRef.value?.validate().catch(() => false)
  const miniValid = await miniFormRef.value?.validate().catch(() => false)
  const payValid = paymentForm.enablePayment ? await payFormRef.value?.validate().catch(() => false) : true

  if (!brandValid || !miniValid || !payValid) return

  savingAll.value = true
  try {
    await Promise.all([
      updateConfigs(buildBrandSaveItems()),
      saveGroup('wechat', '微信小程序配置', pickWechatFormPayload()),
      saveGroup('wechat', '微信公众号配置', pickOaFormPayload()),
      saveGroup('legal', '法律协议与客服', legalForm as unknown as Record<string, unknown>),
      saveGroup('wechat', '微信支付配置', paymentForm as unknown as Record<string, unknown>),
      saveGroup('basic', '插件开关', { plugins: pluginModules.value }),
      saveGroup('storage', '物流配置', buildLogisticsPayload()),
      saveGroup('basic', '通知配置', { notifications: notificationList }),
      saveGroup('basic', '角色矩阵', { roleMatrix: roleList }),
    ])

    markMiniProgramSaved()
    miniSaved.value = true
    paySaved.value = true
    pluginSaved.value = true
    logisticsSaved.value = true
    notificationSaved.value = true
    allSaved.value = true

    ElMessage.success('全部配置已保存')
  } catch (e: unknown) {
    ElMessage.error(e instanceof Error ? e.message : '部分配置保存失败')
  } finally {
    savingAll.value = false
  }
}

async function handleSaveBrandConfig() {
  const valid = await brandFormRef.value?.validate().catch(() => false)
  if (!valid) return

  brandSaving.value = true
  try {
    await updateConfigs(buildBrandSaveItems())
    markMiniProgramSaved()
    ElMessage.success('品牌信息已保存，小程序端将自动同步')
  } catch (e: unknown) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  } finally {
    brandSaving.value = false
  }
}

async function handleSaveOa() {
  oaSaving.value = true
  try {
    await saveGroup('wechat', '微信公众号配置', pickOaFormPayload())
    ElMessage.success('公众号配置已保存')
  } catch (e: unknown) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  } finally {
    oaSaving.value = false
  }
}

async function handleSaveMiniProgram() {
  const valid = await miniFormRef.value?.validate().catch(() => false)
  if (!valid) return
  const uploadKeyValue = miniProgramForm.uploadKey?.trim() || ''
  if (!uploadKeyValue.includes('PRIVATE KEY')) {
    ElMessage.warning('请粘贴完整的代码上传密钥（需包含 BEGIN/END PRIVATE KEY）')
    return
  }

  miniSaving.value = true
  try {
    await saveUploadKey(uploadKeyValue)
    const otherItems = toConfigUpdateItems(
      pickWechatFormPayload(),
      'wechat',
    ).filter(item => item.configKey !== 'wx_upload_key')
    if (otherItems.length) {
      await updateConfigs(otherItems)
    }

    const verifyRes = await getConfigsSilent()
    uploadKeyStored.value = hasStoredUploadKey(extractConfigList(verifyRes.data))
    if (!uploadKeyStored.value) {
      ElMessage.error('上传密钥未写入服务器，请重试')
      return
    }

    markMiniProgramSaved()
    miniSaved.value = true
    ElMessage.success('小程序配置已保存（上传密钥已入库）')
  } catch (e: unknown) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  } finally {
    miniSaving.value = false
  }
}

async function handleSavePayment() {
  const valid = paymentForm.enablePayment ? await payFormRef.value?.validate().catch(() => false) : true
  if (!valid) return

  paySaving.value = true
  try {
    await saveGroup('wechat', '支付配置', paymentForm as unknown as Record<string, unknown>)
    paySaved.value = true
    ElMessage.success('支付配置已保存')
  } catch (e: unknown) {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  } finally {
    paySaving.value = false
  }
}

async function handleTestPay() {
  const valid = paymentForm.enablePayment
    ? await payFormRef.value?.validate().catch(() => false)
    : false
  if (!valid) {
    ElMessage.warning('请先启用支付并填写必填配置')
    return
  }

  payTesting.value = true
  try {
    await saveGroup('wechat', '支付配置', paymentForm as unknown as Record<string, unknown>)
    const res = await testWxPayConfig()
    ElMessage.success(res.data.message || '微信支付配置验证通过')
    paySaved.value = true
  } catch {
    // 请求层会展示后端返回的具体校验原因
  } finally {
    payTesting.value = false
  }
}

function handleSavePlugins() {
  pluginSaving.value = true
  saveGroup('basic', '模块开关', { plugins: pluginModules.value }).then(() => {
    pluginSaved.value = true
    ElMessage.success('模块配置已保存')
  }).catch((e) => {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  }).finally(() => {
    pluginSaving.value = false
  })
}

function handleSaveLogistics() {
  logisticsSaving.value = true
  saveGroup('storage', '物流配置', buildLogisticsPayload()).then(() => {
    logisticsSaved.value = true
    ElMessage.success('物流配置已保存')
  }).catch((e) => {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  }).finally(() => {
    logisticsSaving.value = false
  })
}

function handleSaveNotifications() {
  notificationSaving.value = true
  saveGroup('basic', '通知配置', { notifications: notificationList }).then(() => {
    notificationSaved.value = true
    ElMessage.success('通知配置已保存')
  }).catch((e) => {
    ElMessage.error(e instanceof Error ? e.message : '保存失败')
  }).finally(() => {
    notificationSaving.value = false
  })
}

function onModuleToggle(plugin: PluginModule, enabled: boolean) {
  ElMessage.success(`${plugin.name}已${enabled ? '启用' : '禁用'}`)
}

// 上传相关
function beforeImageUpload(file: File) {
  if (!file.type.startsWith('image/')) {
    ElMessage.error('只能上传图片')
    return false
  }
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('图片不能超过2MB')
    return false
  }
  return true
}

async function handleLogoUpload(options: UploadRequestOptions) {
  try {
    const res = await uploadFile(options.file)
    miniProgramForm.logoUrl = res.data.url
    ElMessage.success('Logo上传成功')
  } catch {
    ElMessage.error('上传失败')
  }
}

function beforeCertUpload(file: File) {
  const ext = file.name.split('.').pop()?.toLowerCase()
  if (!['p12', 'pem', 'key'].includes(ext || '')) {
    ElMessage.error('仅支持 .p12/.pem/.key 商户私钥')
    return false
  }
  return true
}

async function handleCertUpload(options: UploadRequestOptions) {
  try {
    const res = await uploadWxPayPrivateKey(options.file, paymentForm.mchId)
    paymentForm.certUploaded = true
    if (res.data.certSerialNo) paymentForm.certSerialNo = res.data.certSerialNo
    ElMessage.success('商户API私钥已写入支付配置')
  } catch {
    // 请求层会展示私钥格式或 p12 密码错误原因
  }
}

function handlePickAsset() {
  assetPickerVisible.value = true
}

function handleLogoAssetSelected(url: string) {
  miniProgramForm.logoUrl = normalizeUploadUrl(url)
  logoImageBroken.value = false
  assetPickerVisible.value = false
  ElMessage.success('已选择 Logo 图片')
}

function resetRoleForm() {
  roleEditingId.value = null
  roleIconPopoverVisible.value = false
  roleForm.icon = '👤'
  roleForm.name = ''
  roleForm.desc = ''
  roleForm.permissions = []
}

function selectRoleIcon(emoji: string) {
  roleForm.icon = emoji
  roleIconPopoverVisible.value = false
}

function openRoleDialog(role?: RoleItem) {
  if (role) {
    roleEditingId.value = role.id
    roleForm.icon = role.icon
    roleForm.name = role.name
    roleForm.desc = role.desc
    roleForm.permissions = [...role.permissions]
  } else {
    resetRoleForm()
  }
  roleDialogVisible.value = true
}

async function submitRole() {
  const valid = await roleFormRef.value?.validate().catch(() => false)
  if (!valid) return

  const payload: RoleItem = {
    id: roleEditingId.value || `role_${Date.now()}`,
    icon: roleForm.icon.trim() || '👤',
    name: roleForm.name.trim(),
    desc: roleForm.desc.trim(),
    permissions: [...roleForm.permissions],
    builtIn: roleEditingId.value
      ? roleList.find((item) => item.id === roleEditingId.value)?.builtIn
      : false,
    tag: roleEditingId.value
      ? roleList.find((item) => item.id === roleEditingId.value)?.tag
      : undefined,
  }

  const isEdit = !!roleEditingId.value
  const index = roleList.findIndex((item) => item.id === payload.id)
  if (index >= 0) roleList[index] = payload
  else roleList.push(payload)

  roleDialogVisible.value = false
  allSaved.value = false
  ElMessage.success(isEdit ? '角色已更新' : '角色已创建')
}

function handleDeleteRole(role: RoleItem) {
  if (role.builtIn) {
    ElMessage.warning('系统内置角色不可删除')
    return
  }
  ElMessageBox.confirm(`确定删除角色「${role.name}」？`, '删除确认', {
    type: 'warning',
    confirmButtonText: '删除',
    cancelButtonText: '取消',
  }).then(() => {
    const index = roleList.findIndex((item) => item.id === role.id)
    if (index >= 0) roleList.splice(index, 1)
    allSaved.value = false
    ElMessage.success('已删除')
  }).catch(() => {})
}

function handleGetTemplateId() {
  ElMessage.info('请前往微信公众平台获取')
}

function handleTestNotification(row: NotificationItem) {
  if (!row.templateId) {
    ElMessage.warning('请先配置模板ID')
    return
  }
  ElMessage.success(`已发送测试「${row.scene}」`)
}

// 运费模板
function openFreightDialog(row?: FreightTemplate) {
  freightEditingTemplate.value = row ? { ...row } : null
  freightDialogVisible.value = true
}

function handleFreightSave(template: FreightTemplate) {
  const existed = freightTemplates.value.some((item) => item.id === template.id)
  if (template.isDefault) {
    freightTemplates.value.forEach((item) => {
      if (item.id !== template.id) item.isDefault = false
    })
  }
  const index = freightTemplates.value.findIndex((item) => item.id === template.id)
  if (index >= 0) freightTemplates.value[index] = template
  else freightTemplates.value.push(template)

  logisticsSaved.value = false
  allSaved.value = false
  ElMessage.success(existed ? '模板已更新' : '模板已创建')
}

function handleDeleteFreightTemplate(row: FreightTemplate) {
  ElMessageBox.confirm(`确定删除运费模板「${row.name}」？`, '删除确认', {
    type: 'warning',
    confirmButtonText: '删除',
    cancelButtonText: '取消',
  }).then(() => {
    freightTemplates.value = freightTemplates.value.filter((item) => item.id !== row.id)
    logisticsSaved.value = false
    allSaved.value = false
    ElMessage.success('已删除')
  }).catch(() => {})
}

function handleConfigNoLogistics() { ElMessage.info('数字商品无需物流') }

// Watchers
// 注意：不再在watch中自动调用API，避免API失败后回写值导致无限循环
// 支付开关状态变更由用户手动点击"保存支付配置"按钮提交
watch(paymentForm, () => { if (paySaved.value) { paySaved.value = false; allSaved.value = false } }, { deep: true })
watch(logisticsForm, () => { if (logisticsSaved.value) { logisticsSaved.value = false; allSaved.value = false } }, { deep: true })
watch(freightTemplates, () => { if (logisticsSaved.value) { logisticsSaved.value = false; allSaved.value = false } }, { deep: true })
watch(roleList, () => { allSaved.value = false }, { deep: true })
watch(notificationList, () => { if (notificationSaved.value) { notificationSaved.value = false; allSaved.value = false } }, { deep: true })

onMounted(() => {
  fetchConfig()
})
</script>

<style lang="scss" scoped>
/* ============================================
   企业级系统设置页面 - 大厂UI规范版
   设计参考: 阿里云控制台 / 腾讯云后台 / 飞书管理后台
   核心特点: Tab布局 + 紧凑表单 + 卡片分组 + 无空白
   ============================================ */

.enterprise-setting-page {
  min-height: 100vh;
  background: #f5f7fa;
  padding: 0;
  display: flex;
  flex-direction: column;
}

/* ========== 页面头部（大厂标准） ========== */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 32px;
  background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
  border-bottom: 1px solid #e5e7eb;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.header-left {
  flex: 1;
}

.page-title {
  margin: 0 0 8px;
  font-size: 22px;
  font-weight: 700;
  color: #111827;
  letter-spacing: -0.3px;
}

.page-subtitle {
  margin: 0;
  font-size: 14px;
  color: #6b7280;
}

.header-right {
  display: flex;
  gap: 12px;
}

/* ========== 主内容区 ========== */
.main-content {
  flex: 1;
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  padding: 24px;
  box-sizing: border-box;
}

/* ========== Tab标签样式（大厂标准） ========== */
.setting-tabs {
  background: white;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);

  :deep(.el-tabs__header) {
    margin: 0;
    background: #fafbfc;
    border-bottom: 1px solid #e5e7eb;
    border-radius: 12px 12px 0 0;
  }

  :deep(.el-tabs__nav-wrap::after) {
    height: 1px;
    background: transparent;
  }

  :deep(.el-tabs__item) {
    height: 48px;
    line-height: 48px;
    padding: 0 28px;
    font-size: 14px;
    font-weight: 500;
    color: #6b7280;
    transition: all 0.25s ease;

    &.is-active {
      color: #2563eb;
      font-weight: 600;

      &::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 20px;
        right: 20px;
        height: 2px;
        background: #2563eb;
        border-radius: 2px 2px 0 0;
      }
    }

    &:hover {
      color: #374151;
      background: rgba(59, 130, 246, 0.04);
    }
  }
}

.tab-content {
  padding: 28px 32px;
  min-height: 400px;
}

/* ========== 配置区块 ========== */
.config-section {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 24px;
  margin-bottom: 20px;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.section-spacing {
  margin-top: 20px;
}

.section-header {
  display: flex;
  align-items: baseline;
  gap: 16px;
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f3f4f6;
  flex-wrap: wrap;
}

.section-title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
}

.section-desc {
  font-size: 13px;
  color: #9ca3af;
  flex: 1;
}

.header-actions {
  display: flex;
  gap: 8px;
  margin-left: auto;
}

/* ========== 紧凑表单布局 ========== */
.compact-form {
  :deep(.el-form-item) {
    margin-bottom: 18px;
  }

  :deep(.el-form-item__label) {
    font-size: 13px;
    font-weight: 500;
    color: #374151;
    padding-right: 12px;
  }

  :deep(.el-input__wrapper),
  :deep(.el-select__wrapper) {
    border-radius: 6px;
    
    &:hover {
      box-shadow: 0 0 0 1px #d1d5db inset;
    }
  }

  :deep(.el-input__wrapper.is-focus) {
    box-shadow: 0 0 0 2px #3b82f6 inset, 0 0 0 4px rgba(59, 130, 246, 0.08);
  }
}

.form-grid-2col {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
}

.form-grid-3col {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0 20px;
}

/* 特殊组件样式 */
.logo-uploader {
  display: flex;
  gap: 10px;
  align-items: center;
  width: 100%;

  .logo-preview-box {
    width: 56px;
    height: 56px;
    aspect-ratio: 1 / 1;
    flex-shrink: 0;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
    background: #f9fafb;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }

    &.is-empty {
      border-style: dashed;
      background: #fafafa;
    }
  }

  .logo-preview-placeholder {
    font-size: 11px;
    color: #9ca3af;
    user-select: none;
  }

  .logo-input {
    flex: 1;
  }

  .upload-btns {
    display: flex;
    gap: 8px;
    flex-shrink: 0;
  }
}

.env-toggle {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 18px;
  padding: 12px 16px;
  background: #f9fafb;
  border-radius: 8px;
  border: 1px solid #e5e7eb;

  .toggle-label {
    font-size: 13px;
    font-weight: 500;
    color: #374151;
  }
}

.cert-upload-row {
  display: flex;
  align-items: center;
  gap: 12px;

  .upload-hint {
    font-size: 12px;
    color: #9ca3af;
  }
}

.enable-switch {
  margin-left: auto;
}

.action-bar {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 16px;
  margin-top: 16px;
  border-top: 1px solid #f3f4f6;
}

.action-bar-center {
  justify-content: center;
  padding: 24px 0 0;
  margin-top: 24px;
  border-top: none;
}

/* ========== 模块分组卡片 ========== */
.module-groups {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.module-group {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  overflow: hidden;
}

.group-header {
  display: flex;
  align-items: baseline;
  gap: 12px;
  padding: 16px 20px;
  background: linear-gradient(135deg, #eff6ff 0%, #f8fafc 100%);
  border-bottom: 1px solid #dbeafe;
}

.group-title {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: #1e40af;
  display: flex;
  align-items: center;
  gap: 8px;

  .el-icon {
    font-size: 18px;
  }
}

.group-desc {
  font-size: 13px;
  color: #60a5fa;
  flex: 1;
}

.module-cards {
  display: grid;
  gap: 12px;
  padding: 16px 20px;
}

.module-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  background: white;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  transition: all 0.2s ease;

  &:hover {
    border-color: #93c5fd;
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.08);
    transform: translateY(-1px);
  }

  &.disabled {
    opacity: 0.65;
    background: #f9fafb;
  }
}

.card-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  min-width: 0;
}

.card-icon {
  font-size: 24px;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f9ff;
  border-radius: 8px;
  flex-shrink: 0;
}

.card-info {
  flex: 1;
  min-width: 0;
}

.card-name {
  font-size: 14px;
  font-weight: 600;
  color: #111827;
  margin-bottom: 2px;
}

.card-desc {
  font-size: 12px;
  color: #9ca3af;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* ========== 数据表格 ========== */
.data-table {
  width: 100%;
  border-radius: 8px;
  overflow: hidden;

  :deep(th.el-table__cell) {
    background: #f9fafb !important;
    color: #374151;
    font-weight: 600;
    font-size: 13px;
    padding: 12px 16px;
  }

  :deep(td.el-table__cell) {
    font-size: 13px;
    padding: 12px 16px;
  }

  :deep(.el-table__row--striped td) {
    background: #fafbfc;
  }
}

.text-muted {
  color: #9ca3af;
  font-size: 12px;
}

.freight-free-summary {
  font-size: 12px;
  color: #6b7280;
}

.freight-template-section {
  .toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
    flex-wrap: wrap;
  }

  .toolbar-meta {
    font-size: 13px;
    color: #6b7280;
  }

  .toolbar-spacer {
    flex: 1;
  }

  .table-panel {
    background: #fff;
    border: 1px solid #e4e9f2;
    border-radius: 12px;
    padding: 14px;
  }

  .empty-panel {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 160px;
    color: var(--text-muted, #9ca3af);
    font-size: 14px;
  }

  .freight-name-cell {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }

  .freight-name {
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
  }

  .freight-remark {
    font-size: 11px;
    color: #9ca3af;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

.scene-cell {
  display: flex;
  align-items: center;
  gap: 8px;

  .scene-icon {
    font-size: 16px;
  }

  .scene-text {
    font-size: 13px;
    color: #374151;
  }
}

/* ========== 角色卡片（企业版） ========== */
.role-matrix {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
  gap: 16px;
}

.role-card-enterprise {
  padding: 20px;
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  transition: all 0.25s ease;

  &:hover {
    border-color: #93c5fd;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
    transform: translateY(-2px);
  }
}

.role-main {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 16px;
}

.role-avatar {
  font-size: 32px;
  width: 52px;
  height: 52px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
  border-radius: 12px;
  flex-shrink: 0;
}

.role-detail {
  flex: 1;
  min-width: 0;
}

.role-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.role-name {
  font-size: 15px;
  font-weight: 600;
  color: #111827;
}

.role-desc {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
  line-height: 1.5;
}

.role-perms {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 12px;
}

.role-actions {
  display: flex;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid #f3f4f6;
  position: relative;
  z-index: 1;
}

.role-section {
  .toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
  }

  .toolbar-meta {
    font-size: 13px;
    color: #6b7280;
  }

  .toolbar-spacer {
    flex: 1;
  }
}

.role-perm-checkboxes {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px 12px;
  width: 100%;
}

.role-icon-field {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
}

.role-icon-trigger {
  flex-shrink: 0;
  width: 44px;
  height: 44px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  background: #fff;
  border: 1px solid #dce3ef;
  border-radius: 10px;
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;

  &:hover {
    border-color: #2469f0;
    box-shadow: 0 0 0 2px rgba(36, 105, 240, 0.12);
  }
}

.role-icon-hint {
  font-size: 12px;
  color: #9ca3af;
}

.role-icon-library {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 4px;
}

.role-icon-option {
  width: 32px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  background: transparent;
  border: 1px solid transparent;
  border-radius: 8px;
  cursor: pointer;

  &:hover {
    background: #f0f6ff;
  }

  &.active {
    border-color: #2469f0;
    background: #ecf3ff;
  }
}

/* ========== 通用按钮增强 ========== */
.btn-saved {
  --el-button-bg-color: #ecfdf5 !important;
  --el-button-border-color: #a7f3d0 !important;
  --el-button-text-color: #059669 !important;
  animation: saved-pulse 0.35s ease-out;
}

@keyframes saved-pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

/* ========== 响应式适配 ========== */
@media (max-width: 1280px) {
  .main-content {
    padding: 20px;
  }

  .tab-content {
    padding: 24px;
  }

  .form-grid-3col {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 1024px) {
  .page-header {
    padding: 20px 24px;
    flex-direction: column;
    align-items: stretch;
    gap: 16px;
  }

  .header-right {
    justify-content: stretch;

    .el-button {
      flex: 1;
    }
  }

  .form-grid-2col,
  .form-grid-3col {
    grid-template-columns: 1fr;
  }

  .role-matrix {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 768px) {
  .page-header {
    padding: 16px 20px;
  }

  .main-content {
    padding: 16px;
  }

  .tab-content {
    padding: 20px;
  }

  .config-section {
    padding: 20px;
  }

  .section-header {
    flex-direction: column;
    gap: 8px;
  }

  .module-cards {
    grid-template-columns: 1fr;
  }

  .module-card {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
}
</style>
