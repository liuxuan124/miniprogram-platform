<template>
  <div class="content-page">
    <div class="page-header">
      <div>
        <div class="page-title">内容管理</div>
        <div class="page-desc">长文、笔记、图文、视频，支持分类、推荐、上下架。</div>
      </div>
    </div>

    <div class="toolbar">
      <el-input
        v-model="searchForm.keyword"
        class="toolbar-input"
        placeholder="搜索标题"
        clearable
        @keyup.enter="handleSearch"
      />
      <el-select v-model="searchForm.type" class="toolbar-select" placeholder="类型：全部" clearable>
        <el-option
          v-for="item in contentFormatFilterOptions"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
      <el-select v-model="searchForm.categoryId" class="toolbar-select" placeholder="分类：全部" clearable>
        <el-option
          v-for="item in flatCategoryOptions"
          :key="item.id"
          :label="item.label"
          :value="item.id"
        />
      </el-select>
      <el-select v-model="searchForm.source" class="toolbar-select" placeholder="来源：全部" clearable>
        <el-option label="小红书" value="小红书" />
        <el-option label="微信公众号" value="微信公众号" />
        <el-option label="原创" value="原创" />
      </el-select>
      <el-select v-model="searchForm.status" class="toolbar-select" placeholder="状态：全部" clearable>
        <el-option label="草稿" value="draft" />
        <el-option label="已发布" value="published" />
        <el-option label="已下架" value="unpublished" />
      </el-select>
      <el-button @click="handleSearch">搜索</el-button>
      <div class="toolbar-spacer" />
      <el-button @click="categoryModalVisible = true">分类</el-button>
      <el-button @click="syncDialogVisible = true">同步导入</el-button>
      <el-button :disabled="!selectedRows.length" @click="agentDialogVisible = true">
        交给 Agent{{ selectedRows.length ? ` (${selectedRows.length})` : '' }}
      </el-button>
      <el-button :disabled="!selectedRows.length" :loading="batchLoading" @click="handleBatchPublish">
        批量上架{{ selectedRows.length ? ` (${selectedRows.length})` : '' }}
      </el-button>
      <el-button :disabled="!selectedRows.length" :loading="batchLoading" @click="handleBatchUnpublish">
        批量下架{{ selectedRows.length ? ` (${selectedRows.length})` : '' }}
      </el-button>
      <el-button
        type="danger"
        plain
        :disabled="!selectedRows.length"
        :loading="batchLoading"
        @click="handleBatchDelete"
      >
        批量删除{{ selectedRows.length ? ` (${selectedRows.length})` : '' }}
      </el-button>
      <el-button type="primary" @click="handleCreate">+ 新建</el-button>
    </div>

    <div class="table-panel">
      <ListStateWrap
        :loading="loading"
        :empty="!loading && filteredRows.length === 0"
        empty-text="暂无内容数据"
        empty-description="可以新建文章、图文或视频内容"
        @retry="fetchList"
      >
        <template #empty-action>
          <el-button type="primary" @click="handleCreate">+ 新建</el-button>
        </template>

      <el-table
        ref="tableRef"
        :data="filteredRows"
        stripe
        row-key="id"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="48" reserve-selection />
        <el-table-column label="标题" min-width="280">
          <template #default="{ row }">
            <div class="title-cell">
              <span class="title-text">{{ row.title }}</span>
              <el-tag v-if="isRecommended(row)" size="small" effect="plain" type="primary">推荐</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="来源" width="120" align="center">
          <template #default="{ row }">
            <el-tag
              size="small"
              effect="plain"
              :type="platformSourceTagType(row.source) || undefined"
            >
              {{ row.source || '未标注' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="类型" width="110" align="center">
          <template #default="{ row }">
            <el-tag size="small" effect="plain" :type="typeTagType(row) || undefined">{{ row.typeLabel }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="categoryName" label="分类" width="160" show-overflow-tooltip />
        <el-table-column label="状态" width="120" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)" size="small">
              {{ statusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="导入时间" width="168" align="center">
          <template #default="{ row }">{{ formatContentTime(row.importTime) }}</template>
        </el-table-column>
        <el-table-column label="阅读" width="100" align="center">
          <template #default="{ row }">{{ row.viewCount ?? '—' }}</template>
        </el-table-column>
        <el-table-column label="操作" width="360" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="handlePreview(row)">预览</el-button>
            <el-button link type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button link size="small" @click="handleTogglePublish(row)">
              {{ row.status === 'published' ? '下架' : '上架' }}
            </el-button>
            <el-button link size="small" @click="toggleRecommend(row)">
              {{ isRecommended(row) ? '取消推荐' : '设为推荐' }}
            </el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap">
        <div class="list-metrics">
          <div class="list-metrics__counts">
            <button
              type="button"
              class="metric-chip"
              :class="{ active: searchForm.status === 'draft' }"
              @click="toggleStatusFilter('draft')"
            >
              草稿 <strong>{{ statusMetrics.draft }}</strong>
            </button>
            <button
              type="button"
              class="metric-chip metric-chip--published"
              :class="{ active: searchForm.status === 'published' }"
              @click="toggleStatusFilter('published')"
            >
              已发布 <strong>{{ statusMetrics.published }}</strong>
            </button>
            <button
              type="button"
              class="metric-chip metric-chip--unpublished"
              :class="{ active: searchForm.status === 'unpublished' }"
              @click="toggleStatusFilter('unpublished')"
            >
              已下架 <strong>{{ statusMetrics.unpublished }}</strong>
            </button>
            <button
              type="button"
              class="metric-chip metric-chip--total"
              :class="{ active: !searchForm.status }"
              @click="toggleStatusFilter('')"
            >
              合计 <strong>{{ statusMetrics.total }}</strong>
            </button>
          </div>
          <div class="list-metrics__summary">
            <span>当前列表 <strong>{{ pagination.total }}</strong> 条</span>
            <span v-if="pageRangeText"> · 本页 {{ pageRangeText }}</span>
            <span v-if="searchForm.type"> · 类型筛选后本页 {{ filteredRows.length }} 条</span>
          </div>
        </div>
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="pagination.total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="fetchList"
          @current-change="fetchList"
        />
      </div>
      </ListStateWrap>
    </div>

    <el-dialog v-model="categoryModalVisible" title="内容分类管理" width="760px" destroy-on-close>
      <div class="category-tip">
        点「发布」后，该分类会出现在「跨境资讯」顶栏，并同步到发文时的「内容分类」下拉。未发布的分类仅在本处管理。
      </div>
      <div class="category-list" v-loading="categoryLoading">
        <div v-for="item in categoryTree" :key="item.id" class="category-item">
          <div class="category-row">
            <span class="category-name">
              ⠿ {{ item.name }}
              <el-tag size="small" :type="isCategoryPublished(item) ? 'success' : 'info'" class="cat-pub-tag">
                {{ isCategoryPublished(item) ? '已发布到顶栏' : '未发布' }}
              </el-tag>
            </span>
            <div class="category-actions">
              <el-button
                size="small"
                :type="isCategoryPublished(item) ? 'warning' : 'primary'"
                @click="toggleCategoryPublish(item)"
              >
                {{ isCategoryPublished(item) ? '取消发布' : '发布' }}
              </el-button>
              <el-button size="small" @click="openCategoryDialog('create', item)">+ 子分类</el-button>
              <el-button size="small" @click="openCategoryDialog('edit', item)">重命名</el-button>
              <el-button size="small" type="danger" plain @click="removeCategory(item)">删除</el-button>
            </div>
          </div>
          <div v-if="item.children.length" class="sub-list">
            <div v-for="sub in item.children" :key="sub.id" class="sub-row">
              <span>
                ⠿ {{ sub.name }}
                <el-tag size="small" :type="isCategoryPublished(sub) ? 'success' : 'info'" class="cat-pub-tag">
                  {{ isCategoryPublished(sub) ? '已发布' : '未发布' }}
                </el-tag>
              </span>
              <div class="category-actions">
                <el-button
                  size="small"
                  :type="isCategoryPublished(sub) ? 'warning' : 'primary'"
                  @click="toggleCategoryPublish(sub)"
                >
                  {{ isCategoryPublished(sub) ? '取消发布' : '发布' }}
                </el-button>
                <el-button size="small" @click="openCategoryDialog('edit', sub)">编辑</el-button>
                <el-button size="small" type="danger" plain @click="removeCategory(sub)">删除</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-button type="primary" class="add-root-btn" @click="openCategoryDialog('create', null)">+ 新增一级分类</el-button>
    </el-dialog>

    <el-dialog
      v-model="syncDialogVisible"
      title="同步导入小红书 / 公众号内容"
      width="720px"
      destroy-on-close
      @open="onSyncDialogOpen"
      @closed="onSyncDialogClosed"
    >
      <el-tabs v-model="syncTab">
        <el-tab-pane label="公众号全量导入" name="wechat">
          <el-alert
            type="success"
            :closable="false"
            show-icon
            style="margin-bottom: 12px"
            title="从企业服务号拉取全部「已发布」内容：长文导入为文章，贴图（小红书风格多图+短文）导入为笔记。需在「系统设置 → 基础配置 → 微信公众号配置」填写公众号 AppID/AppSecret。"
          />
          <el-form label-width="96px">
            <el-form-item label="默认分类">
              <el-select v-model="wechatSyncForm.categoryId" placeholder="不指定分类" clearable style="width: 100%">
                <el-option
                  v-for="item in flatCategoryOptions"
                  :key="item.id"
                  :label="item.label"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="同步范围">
              <el-radio-group v-model="wechatSyncForm.syncScope">
                <el-radio-button value="all">贴图 + 文章</el-radio-button>
                <el-radio-button value="newspic">仅贴图</el-radio-button>
                <el-radio-button value="news">仅文章</el-radio-button>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="导入状态">
              <el-radio-group v-model="wechatSyncForm.publish">
                <el-radio-button :value="true">直接上架（已发布）</el-radio-button>
                <el-radio-button :value="false">存为草稿</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-form>
          <div v-if="importTask && importTask.type === 'sync' && (isImportRunning(importTask) || importTask.status === 'success')" class="sync-progress-box">
            <el-progress
              :percentage="importTask.status === 'success' ? 100 : importProgressPercent(importTask)"
              :status="importTask.status === 'success' ? 'success' : undefined"
              :stroke-width="14"
              :striped="isImportRunning(importTask)"
              :striped-flow="isImportRunning(importTask)"
            />
            <div class="sync-progress-meta">
              <template v-if="importTask.status === 'success'">导入完成</template>
              <template v-else>
                {{ importTask.processed }} / {{ Math.max(importTask.total, importTask.processed) || '…' }}
                <span v-if="importTask.currentTitle"> · 正在处理：{{ importTask.currentTitle }}</span>
              </template>
            </div>
          </div>
          <div v-if="wechatSyncResult" class="sync-result-box" :class="{ success: !wechatSyncResult.failed, danger: !!wechatSyncResult.failed }">
            <div class="sync-result-title">{{ wechatSyncResult.failed ? '导入结束（含失败）' : '导入成功' }}</div>
            <div class="sync-result-stats">
              <span>新建 <b>{{ wechatSyncResult.created }}</b></span>
              <span>更新 <b>{{ wechatSyncResult.updated }}</b></span>
              <span>跳过 <b>{{ wechatSyncResult.skipped }}</b></span>
              <span>失败 <b>{{ wechatSyncResult.failed }}</b></span>
            </div>
            <div class="sync-result-msg">{{ wechatSyncResult.message }}</div>
            <div v-if="wechatSyncResult.failures?.length" class="sync-failures">
              <div v-for="(item, idx) in wechatSyncResult.failures" :key="idx">
                {{ item.title }}：{{ item.reason }}
              </div>
            </div>
            <div class="sync-result-hint">列表已按「{{ wechatSyncForm.publish ? '已发布' : '草稿' }}」刷新，可关闭弹窗查看。</div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="公众号链接导入" name="wechat-url">
          <el-alert
            type="info"
            :closable="false"
            show-icon
            style="margin-bottom: 12px"
            title="粘贴 mp.weixin.qq.com/s/... 文章链接，可导入 API 拉不到的历史长文。每行一条，或用逗号/空格分隔。正文图片会自动转存到服务器。"
          />
          <el-form label-width="96px">
            <el-form-item label="文章链接">
              <el-input
                v-model="wechatUrlForm.urlText"
                type="textarea"
                :rows="10"
                placeholder="每行一条，例如：
https://mp.weixin.qq.com/s/6hytke48TCsE8NJk_DQyTQ"
              />
            </el-form-item>
            <el-form-item label="默认分类">
              <el-select v-model="wechatUrlForm.categoryId" placeholder="不指定分类" clearable style="width: 100%">
                <el-option
                  v-for="item in flatCategoryOptions"
                  :key="item.id"
                  :label="item.label"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="导入状态">
              <el-radio-group v-model="wechatUrlForm.publish">
                <el-radio-button :value="true">直接上架（已发布）</el-radio-button>
                <el-radio-button :value="false">存为草稿</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-form>
          <div v-if="importTask && importTask.type === 'url' && (isImportRunning(importTask) || importTask.status === 'success')" class="sync-progress-box">
            <el-progress
              :percentage="importTask.status === 'success' ? 100 : importProgressPercent(importTask)"
              :status="importTask.status === 'success' ? 'success' : undefined"
              :stroke-width="14"
              :striped="isImportRunning(importTask)"
              :striped-flow="isImportRunning(importTask)"
            />
            <div class="sync-progress-meta">
              <template v-if="importTask.status === 'success'">导入完成</template>
              <template v-else>
                {{ importTask.processed }} / {{ Math.max(importTask.total, importTask.processed) || '…' }}
                <span v-if="importTask.currentTitle"> · 正在处理：{{ importTask.currentTitle }}</span>
              </template>
            </div>
          </div>
          <div v-if="wechatUrlResult" class="sync-result-box" :class="{ success: !wechatUrlResult.failed, danger: !!wechatUrlResult.failed }">
            <div class="sync-result-title">{{ wechatUrlResult.failed ? '导入结束（含失败）' : '导入成功' }}</div>
            <div class="sync-result-stats">
              <span>新建 <b>{{ wechatUrlResult.created }}</b></span>
              <span>更新 <b>{{ wechatUrlResult.updated }}</b></span>
              <span>跳过 <b>{{ wechatUrlResult.skipped }}</b></span>
              <span>失败 <b>{{ wechatUrlResult.failed }}</b></span>
            </div>
            <div class="sync-result-msg">{{ wechatUrlResult.message }}</div>
            <div v-if="wechatUrlResult.failures?.length" class="sync-failures">
              <div v-for="(item, idx) in wechatUrlResult.failures" :key="idx">
                {{ item.title }}：{{ item.reason }}
              </div>
            </div>
            <div class="sync-result-hint">列表已按「{{ wechatUrlForm.publish ? '已发布' : '草稿' }}」刷新，可关闭弹窗查看。</div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="JSON 手动导入" name="json">
      <el-alert
        type="info"
        :closable="false"
        show-icon
        style="margin-bottom: 12px"
        title="小红书暂无稳定官方拉取接口，建议粘贴导出 JSON；公众号也可先用 JSON 手动导入。"
      />
      <el-form label-width="88px">
        <el-form-item label="默认来源">
          <el-radio-group v-model="syncForm.defaultSource">
            <el-radio-button value="小红书">小红书</el-radio-button>
            <el-radio-button value="微信公众号">微信公众号</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="导入内容">
          <el-input
            v-model="syncForm.jsonText"
            type="textarea"
            :rows="12"
            placeholder='粘贴 JSON 数组，例如：
[
  {
    "title": "文章标题",
    "summary": "摘要",
    "source": "小红书",
    "viewCount": 1000,
    "likeCount": 20,
    "publish": true
  }
]'
          />
        </el-form-item>
      </el-form>
        </el-tab-pane>
      </el-tabs>
      <template #footer>
        <template v-if="syncTab === 'wechat'">
          <el-button @click="closeSyncDialogSafely">关闭</el-button>
          <el-button
            type="primary"
            :loading="wechatSyncSubmitting"
            :disabled="isImportRunning(importTask)"
            @click="handleWeChatSyncImport"
          >
            {{ isImportRunning(importTask) && importTask?.type === 'sync' ? '导入中…' : (wechatSyncResult ? '再导一批' : '开始全量导入') }}
          </el-button>
        </template>
        <template v-else-if="syncTab === 'wechat-url'">
          <el-button @click="closeSyncDialogSafely">关闭</el-button>
          <el-button
            type="primary"
            :loading="wechatUrlSubmitting"
            :disabled="isImportRunning(importTask)"
            @click="handleWeChatUrlImport"
          >
            {{ isImportRunning(importTask) && importTask?.type === 'url' ? '导入中…' : (wechatUrlResult ? '再导一批' : '开始链接导入') }}
          </el-button>
        </template>
        <template v-else>
        <el-button @click="fillSyncSample">填入示例</el-button>
        <el-button @click="syncDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="syncSubmitting" @click="handleSyncImport">开始导入</el-button>
        </template>
      </template>
    </el-dialog>

    <el-dialog
      v-model="categoryDialogVisible"
      :title="categoryDialogMode === 'create' ? '新增分类' : '重命名分类'"
      width="420px"
      destroy-on-close
    >
      <el-form ref="categoryFormRef" :model="categoryForm" :rules="categoryRules" label-width="78px">
        <el-form-item label="分类名称" prop="name">
          <el-input v-model="categoryForm.name" maxlength="30" show-word-limit placeholder="请输入分类名称" />
        </el-form-item>
        <el-form-item label="上级分类">
          <el-select v-model="categoryForm.parentId" placeholder="无上级分类" clearable style="width: 100%">
            <el-option :value="null" label="无上级分类（一级）" />
            <el-option v-for="item in allFlatCategoryOptions" :key="item.id" :value="item.id" :label="item.label" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="categoryDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="categorySubmitting" @click="submitCategory">确定</el-button>
      </template>
    </el-dialog>

    <el-dialog
      v-model="previewVisible"
      title="内容预览"
      width="500px"
      append-to-body
      destroy-on-close
      align-center
      class="content-preview-dialog"
    >
      <p v-if="previewSubtitle" class="preview-dialog-subtitle">{{ previewSubtitle }}</p>
      <div v-loading="previewLoading" class="preview-dialog-body">
        <ContentPreviewPanel v-if="previewModel" :model="previewModel" />
      </div>
    </el-dialog>

    <ContentAgentDialog
      v-model="agentDialogVisible"
      :content-ids="selectedRows.map((r) => r.id)"
      @done="fetchList"
    />

  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onActivated, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules, TableInstance } from 'element-plus'
import ListStateWrap from '@/components/ListStateWrap.vue'
import ContentPreviewPanel from '@/components/content/ContentPreviewPanel.vue'
import ContentAgentDialog from '@/views/content/ContentAgentDialog.vue'
import {
  getContentList,
  getContentDetail,
  publishContent,
  unpublishContent,
  deleteContent,
  updateContent,
  getCategoryList,
  createCategory,
  updateCategory,
  deleteCategory,
  createContent,
} from '@/api/content'
import {
  syncWeChatPublishedContents,
  importWeChatArticleUrls,
  getImportTask,
  getRunningImportTask,
  type WeChatContentSyncResult,
  type WeChatSyncScope,
  type ImportTask,
} from '@/api/wechat'
import { buildPreviewFromDetail, type ContentPreviewModel } from '@/utils/content-preview'
import { inferContentFormat, parseContentTags } from '@/utils/content-format'
import { platformSourceTagType, resolvePlatformSource } from '@/utils/content-source'
import {
  CONTENT_FORMAT_FILTER_OPTIONS,
  CONTENT_FORMAT_META,
  type ContentFormatType,
} from '@/types/content'

const contentFormatFilterOptions = CONTENT_FORMAT_FILTER_OPTIONS

type RawRecord = Record<string, any>
type ContentStatus = 'draft' | 'published' | 'unpublished' | 'archived'

interface ContentRow {
  id: number
  title: string
  status: ContentStatus
  categoryId?: number
  categoryName: string
  source: string
  typeLabel: string
  typeValue: ContentFormatType
  viewCount: number | null
  recommended: boolean
  tags: string[]
  sortOrder: number
  createTime: string
  importTime: string
}

interface CategoryNode {
  id: number
  name: string
  parentId: number | null
  status: string
  sort: number
  children: CategoryNode[]
}

const route = useRoute()
const router = useRouter()
const loading = ref(false)
const batchLoading = ref(false)
const tableRef = ref<TableInstance>()
const selectedRows = ref<ContentRow[]>([])
const categoryLoading = ref(false)
const rows = ref<ContentRow[]>([])
const categoryTree = ref<CategoryNode[]>([])
const RECOMMEND_TAG = '推荐'

const searchForm = reactive({
  keyword: '',
  type: '',
  source: '',
  status: '' as '' | ContentStatus,
  categoryId: undefined as number | undefined,
})

const syncDialogVisible = ref(false)
const agentDialogVisible = ref(false)
const syncTab = ref('wechat')
const syncSubmitting = ref(false)
const wechatSyncSubmitting = ref(false)
const wechatUrlSubmitting = ref(false)
const wechatSyncResult = ref<WeChatContentSyncResult | null>(null)
const wechatUrlResult = ref<WeChatContentSyncResult | null>(null)
const importTask = ref<ImportTask | null>(null)
let importPollTimer: ReturnType<typeof setInterval> | null = null
let importPollFailCount = 0
const previewVisible = ref(false)
const previewLoading = ref(false)
const previewSubtitle = ref('')
const previewModel = ref<ContentPreviewModel | null>(null)
const syncForm = reactive({
  defaultSource: '小红书',
  jsonText: '',
})
const wechatSyncForm = reactive({
  categoryId: undefined as number | undefined,
  publish: false,
  syncScope: 'all' as WeChatSyncScope,
})
const wechatUrlForm = reactive({
  urlText: '',
  categoryId: undefined as number | undefined,
  publish: false,
})

const WECHAT_SYNC_SCOPE_LABEL: Record<WeChatSyncScope, string> = {
  all: '贴图 + 文章',
  newspic: '仅贴图',
  news: '仅文章',
}

const pagination = reactive({
  page: 1,
  pageSize: 10,
  total: 0,
})

const statusMetrics = reactive({
  draft: 0,
  published: 0,
  unpublished: 0,
  total: 0,
})

function normalizeStatus(statusRaw: unknown): ContentStatus {
  if (typeof statusRaw === 'number') {
    if (statusRaw === 1) return 'published'
    if (statusRaw === 2) return 'unpublished'
    return 'draft'
  }
  const v = String(statusRaw || '').toLowerCase()
  if (v === 'published') return 'published'
  if (v === 'unpublished' || v === 'offline') return 'unpublished'
  if (v === 'archived') return 'archived'
  return 'draft'
}

function inferType(raw: RawRecord): { typeLabel: string; typeValue: ContentFormatType } {
  const typeValue = inferContentFormat(raw as Record<string, unknown>)
  return {
    typeLabel: CONTENT_FORMAT_META[typeValue]?.label ?? '长文',
    typeValue,
  }
}

function typeTagType(row: ContentRow): 'success' | 'warning' | 'info' | 'danger' | '' {
  return CONTENT_FORMAT_META[row.typeValue]?.tagType ?? ''
}

function normalizeArticle(raw: RawRecord): ContentRow {
  const type = inferType(raw)
  const tags = parseContentTags(raw.tags)
  const sortOrder = Number(raw.sortOrder ?? raw.sort ?? 0)
  const recommended = tags.includes(RECOMMEND_TAG) || sortOrder < 0 || Boolean(
    raw.recommended ?? raw.recommend ?? raw.isRecommend ?? raw.is_recommend ?? false
  )
  const viewRaw = raw.viewCount ?? raw.view_count ?? raw.views
  return {
    id: Number(raw.id),
    title: raw.title || '未命名内容',
    status: normalizeStatus(raw.status),
    categoryId: Number(raw.categoryId ?? raw.category_id) || undefined,
    categoryName: raw.categoryName || raw.category_name || '未分类',
    source: resolvePlatformSource({
      source: String(raw.source || '').trim(),
      tags,
      externalSource: String(raw.externalSource || raw.external_source || '').trim(),
    }),
    typeLabel: type.typeLabel,
    typeValue: type.typeValue,
    viewCount: Number.isFinite(Number(viewRaw)) ? Number(viewRaw) : null,
    recommended,
    tags,
    sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    createTime: String(raw.createTime || raw.create_time || raw.createdAt || raw.created_at || ''),
    importTime: String(raw.updateTime || raw.update_time || raw.importTime || raw.import_time || raw.createTime || raw.create_time || raw.createdAt || raw.created_at || ''),
  }
}

function formatContentTime(value?: string): string {
  if (!value) return '—'
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) {
    return String(value).replace('T', ' ').slice(0, 16)
  }
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const h = String(d.getHours()).padStart(2, '0')
  const min = String(d.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${day} ${h}:${min}`
}

function normalizeCategory(raw: RawRecord): CategoryNode {
  const children = Array.isArray(raw.children) ? raw.children.map((c: RawRecord) => normalizeCategory(c)) : []
  const rawStatus = raw.status
  const normalizedStatus = typeof rawStatus === 'number'
    ? (rawStatus === 1 ? 'enabled' : 'disabled')
    : (rawStatus || 'enabled')
  return {
    id: Number(raw.id),
    name: raw.name || '未命名分类',
    parentId: raw.parentId ?? raw.parent_id ?? null,
    status: normalizedStatus,
    sort: Number(raw.sortOrder ?? raw.sort ?? 0),
    children,
  }
}

const flatCategoryOptions = computed(() => {
  const list: Array<{ id: number; label: string }> = []
  const walk = (arr: CategoryNode[], prefix = '') => {
    arr.forEach((item) => {
      // 仅「已发布到顶栏」的分类出现在发文/筛选下拉（与图1一致）
      if (!isCategoryPublished(item)) return
      list.push({ id: item.id, label: `${prefix}${item.name}` })
      if (item.children.length) walk(item.children, `${prefix}└ `)
    })
  }
  walk(categoryTree.value)
  return list
})

/** 全部一级分类（含未发布），供弹窗里选上级 */
const allFlatCategoryOptions = computed(() => {
  const list: Array<{ id: number; label: string }> = []
  categoryTree.value.forEach((item) => {
    list.push({ id: item.id, label: item.name })
  })
  return list
})

const filteredRows = computed(() => {
  // 类型靠正文推断，服务端无字段，仅在本页结果内二次过滤
  return rows.value.filter((row) => {
    const hitType = !searchForm.type || row.typeValue === searchForm.type
    return hitType
  })
})

const pageRangeText = computed(() => {
  const visible = filteredRows.value.length
  if (!visible || !pagination.total) return ''
  const start = (pagination.page - 1) * pagination.pageSize + 1
  const end = start + visible - 1
  return `${start}-${Math.min(end, pagination.total)}`
})

function metricQueryBase(): Record<string, unknown> {
  return {
    current: 1,
    size: 1,
    keyword: searchForm.keyword || undefined,
    categoryId: searchForm.categoryId,
    category_id: searchForm.categoryId,
    source: searchForm.source || undefined,
  }
}

async function fetchStatusMetricCount(status?: ContentStatus): Promise<number> {
  const res = await getContentList({
    ...metricQueryBase(),
    status: status || undefined,
  } as any)
  const data = (res as any).data || {}
  return Number(data.total || 0)
}

async function fetchStatusMetrics() {
  try {
    const [draft, published, unpublished, total] = await Promise.all([
      fetchStatusMetricCount('draft'),
      fetchStatusMetricCount('published'),
      fetchStatusMetricCount('unpublished'),
      fetchStatusMetricCount(),
    ])
    statusMetrics.draft = draft
    statusMetrics.published = published
    statusMetrics.unpublished = unpublished
    statusMetrics.total = total
  } catch {
    statusMetrics.draft = 0
    statusMetrics.published = 0
    statusMetrics.unpublished = 0
    statusMetrics.total = pagination.total
  }
}

function toggleStatusFilter(status: ContentStatus | '') {
  searchForm.status = searchForm.status === status ? '' : status
  pagination.page = 1
  fetchList()
}

async function fetchList() {
  loading.value = true
  try {
    const params: Record<string, any> = {
      current: pagination.page,
      size: pagination.pageSize,
      page: pagination.page,
      page_size: pagination.pageSize,
      keyword: searchForm.keyword || undefined,
      categoryId: searchForm.categoryId,
      category_id: searchForm.categoryId,
      source: searchForm.source || undefined,
      status: searchForm.status || undefined,
    }
    const res = await getContentList(params as any)
    const data = (res as any).data || {}
    const list = Array.isArray(data) ? data : (data.records || data.list || data.items || [])
    rows.value = Array.isArray(list) ? list.map((item: RawRecord) => normalizeArticle(item)) : []
    const serverTotal = Number(data.total || rows.value.length || 0)
    // 有类型筛选时，总数按本页过滤结果估算展示（避免与服务端不一致误导）
    pagination.total = searchForm.type ? filteredRows.value.length : serverTotal
    await fetchStatusMetrics()
    clearSelection()
  } catch {
    rows.value = []
    pagination.total = 0
    clearSelection()
    ElMessage.error('加载内容列表失败')
  } finally {
    loading.value = false
  }
}

function handleSelectionChange(selection: ContentRow[]) {
  selectedRows.value = selection
}

function clearSelection() {
  selectedRows.value = []
  nextTick(() => tableRef.value?.clearSelection())
}

async function fetchCategories() {
  categoryLoading.value = true
  try {
    const res = await getCategoryList()
    const rawList = (res as any).data || []
    categoryTree.value = Array.isArray(rawList) ? rawList.map((item: RawRecord) => normalizeCategory(item)) : []
  } catch {
    categoryTree.value = []
  } finally {
    categoryLoading.value = false
  }
}

function handleSearch() {
  pagination.page = 1
  fetchList()
}

function fillSyncSample() {
  syncForm.jsonText = JSON.stringify(
    [
      {
        title: '示例：跨境干货标题',
        summary: '一句话摘要，方便小程序列表展示',
        source: syncForm.defaultSource,
        viewCount: 1000,
        likeCount: 20,
        publish: true,
      },
    ],
    null,
    2,
  )
}

async function handleWeChatSyncImport() {
  wechatSyncSubmitting.value = true
  wechatSyncResult.value = null
  try {
    const scopeLabel = WECHAT_SYNC_SCOPE_LABEL[wechatSyncForm.syncScope]
    const statusLabel = wechatSyncForm.publish ? '已发布' : '草稿'
    await ElMessageBox.confirm(
      `将从公众号拉取全部已发布图文，同步范围：${scopeLabel}；入库状态：${statusLabel}。已存在的条目会按本次选项更新，是否继续？`,
      '公众号全量导入',
      { type: 'warning', confirmButtonText: '开始导入', cancelButtonText: '取消' },
    )
    const res = await syncWeChatPublishedContents({
      categoryId: wechatSyncForm.categoryId,
      publish: wechatSyncForm.publish,
      syncScope: wechatSyncForm.syncScope,
    })
    await handleImportSubmitResponse(res, 'sync')
  } catch (e: any) {
    if (e !== 'cancel' && e?.message !== 'cancel') {
      ElMessage.error(e?.message || '公众号导入失败')
    }
  } finally {
    wechatSyncSubmitting.value = false
  }
}

function parseWeChatUrlLines(text: string): string[] {
  return String(text || '')
    .split(/[\n,，;；\s]+/)
    .map((s) => s.trim())
    .filter((s) => s.includes('mp.weixin.qq.com/s/'))
}

async function handleWeChatUrlImport() {
  const urls = parseWeChatUrlLines(wechatUrlForm.urlText)
  if (!urls.length) {
    ElMessage.warning('请粘贴至少一条有效的公众号文章链接（mp.weixin.qq.com/s/...）')
    return
  }
  if (urls.length > 10) {
    ElMessage.warning('单次最多导入 10 条链接，请分批提交')
    return
  }
  wechatUrlSubmitting.value = true
  wechatUrlResult.value = null
  try {
    const statusLabel = wechatUrlForm.publish ? '已发布' : '草稿'
    await ElMessageBox.confirm(
      `将导入 ${urls.length} 条公众号链接，入库状态：${statusLabel}。相同链接或同标题会更新已有内容，是否继续？`,
      '公众号链接导入',
      { type: 'warning', confirmButtonText: '开始导入', cancelButtonText: '取消' },
    )
    const res = await importWeChatArticleUrls({
      urls,
      categoryId: wechatUrlForm.categoryId,
      publish: wechatUrlForm.publish,
    })
    await handleImportSubmitResponse(res, 'url')
  } catch (e: any) {
    if (e !== 'cancel' && e?.message !== 'cancel') {
      ElMessage.error(e?.message || '链接导入失败')
    }
  } finally {
    wechatUrlSubmitting.value = false
  }
}

function isImportTaskPayload(data: any): data is ImportTask {
  return !!(data && typeof data === 'object' && data.taskId && data.status)
}

function isSyncResultPayload(data: any): data is WeChatContentSyncResult {
  return !!(data && typeof data === 'object' && typeof data.message === 'string' && !data.taskId)
}

function isImportRunning(task: ImportTask | null | undefined) {
  return !!task && (task.status === 'pending' || task.status === 'running')
}

function importProgressPercent(task: ImportTask | null | undefined) {
  if (!task) return 0
  const total = Math.max(task.total || 0, 1)
  return Math.min(100, Math.round((Math.min(task.processed, total) / total) * 100))
}

function stopImportPolling() {
  if (importPollTimer) {
    clearInterval(importPollTimer)
    importPollTimer = null
  }
  importPollFailCount = 0
}

async function handleImportSubmitResponse(res: any, expectedType: 'sync' | 'url') {
  const data = (res as any)?.data ?? res
  if (isImportTaskPayload(data) && isImportRunning(data)) {
    importTask.value = data
    if (data.type === 'sync') syncTab.value = 'wechat'
    if (data.type === 'url') syncTab.value = 'wechat-url'
    ElMessage.info('导入任务已启动，正在后台处理…')
    startImportPolling(data.taskId)
    return
  }
  if (isImportTaskPayload(data) && data.status === 'success' && data.result) {
    applyImportResult(data.result, data.type || expectedType)
    return
  }
  if (isSyncResultPayload(data)) {
    applyImportResult(data, expectedType)
    return
  }
  ElMessage.warning('导入已提交，但未拿到可识别的进度信息')
}

function applyImportResult(result: WeChatContentSyncResult, type: string) {
  const asPublish = type === 'url' ? wechatUrlForm.publish : wechatSyncForm.publish
  if (type === 'url') {
    wechatUrlResult.value = result
  } else {
    wechatSyncResult.value = result
  }
  // 保留任务态为 success，弹窗内进度条停在 100%
  if (importTask.value) {
    importTask.value = {
      ...importTask.value,
      status: 'success',
      processed: Math.max(importTask.value.processed, importTask.value.total, result.totalArticles || 0),
      total: Math.max(importTask.value.total, result.totalArticles || 0),
    }
  }
  // 切到对应状态筛选，避免「存为草稿」后列表仍看已发布导致以为没导入
  searchForm.status = asPublish ? 'published' : 'draft'
  pagination.page = 1
  ElMessage.success(
    `导入完成：新建 ${result.created}，更新 ${result.updated}` +
      (result.failed ? `，失败 ${result.failed}` : ''),
  )
  fetchList()
}

function startImportPolling(taskId: string) {
  stopImportPolling()
  importPollFailCount = 0
  const tick = async () => {
    try {
      const res = await getImportTask(taskId)
      const task = ((res as any)?.data ?? res) as ImportTask
      importPollFailCount = 0
      if (!task?.taskId) return
      importTask.value = task
      if (task.type === 'sync') syncTab.value = 'wechat'
      if (task.type === 'url') syncTab.value = 'wechat-url'
      if (task.status === 'success') {
        stopImportPolling()
        if (task.result) {
          applyImportResult(task.result, task.type)
        } else {
          ElMessage.success('导入完成')
          fetchList()
        }
      } else if (task.status === 'failed') {
        stopImportPolling()
        ElMessage.error(task.error || '导入失败')
        if (task.type === 'url') {
          wechatUrlResult.value = {
            totalPublishRecords: 0,
            totalArticles: 0,
            created: 0,
            updated: 0,
            skipped: 0,
            failed: 1,
            message: task.error || '导入失败',
          }
        } else {
          wechatSyncResult.value = {
            totalPublishRecords: 0,
            totalArticles: 0,
            created: 0,
            updated: 0,
            skipped: 0,
            failed: 1,
            message: task.error || '导入失败',
          }
        }
      }
    } catch {
      importPollFailCount += 1
      if (importPollFailCount >= 3) {
        stopImportPolling()
        ElMessage.error('进度查询连续失败，请稍后重新打开弹窗查看')
      }
    }
  }
  tick()
  importPollTimer = setInterval(tick, 2000)
}

async function onSyncDialogOpen() {
  try {
    const res = await getRunningImportTask()
    const task = ((res as any)?.data ?? res) as ImportTask | null
    if (task && isImportRunning(task)) {
      importTask.value = task
      if (task.type === 'sync') syncTab.value = 'wechat'
      if (task.type === 'url') syncTab.value = 'wechat-url'
      startImportPolling(task.taskId)
    }
  } catch {
    /* ignore */
  }
}

function onSyncDialogClosed() {
  stopImportPolling()
}

function closeSyncDialogSafely() {
  if (isImportRunning(importTask.value)) {
    ElMessage.info('任务在后台继续，可稍后回来查看进度')
  }
  syncDialogVisible.value = false
}

onBeforeUnmount(() => {
  stopImportPolling()
})


async function handleSyncImport() {
  let items: any[] = []
  try {
    const parsed = JSON.parse(syncForm.jsonText || '[]')
    items = Array.isArray(parsed) ? parsed : [parsed]
  } catch {
    ElMessage.error('JSON 格式不正确，请检查后重试')
    return
  }
  if (!items.length) {
    ElMessage.warning('没有可导入的内容')
    return
  }

  syncSubmitting.value = true
  let success = 0
  let failed = 0
  try {
    for (const item of items) {
      const title = String(item?.title || '').trim()
      if (!title) {
        failed += 1
        continue
      }
      const source = String(item.source || syncForm.defaultSource || '小红书').trim()
      const summary = String(item.summary || item.desc || title).slice(0, 512)
      const defaultCategoryId = flatCategoryOptions.value[0]?.id
      try {
        const res = await createContent({
          title: title.slice(0, 128),
          summary,
          source,
          author: item.author || '跨境IP博主',
          content:
            item.content ||
            `<h2>${title}</h2><p><strong>来源</strong>：${source}</p><p>${summary}</p>`,
          coverImage: item.coverImage || item.cover || '',
          tags: Array.isArray(item.tags) ? item.tags : [source],
          categoryId: item.categoryId || defaultCategoryId,
          sortOrder: Number(item.sortOrder || 0),
        } as any)
        const id = Number((res as any)?.data?.id)
        if (item.publish !== false && id) {
          await publishContent(id)
        }
        success += 1
      } catch {
        failed += 1
      }
    }
    ElMessage.success(`导入完成：成功 ${success} 条${failed ? `，失败 ${failed} 条` : ''}`)
    syncDialogVisible.value = false
    syncForm.jsonText = ''
    fetchList()
  } finally {
    syncSubmitting.value = false
  }
}

function handleCreate() {
  router.push({ name: 'ContentEdit', query: { mode: 'create' } })
}

function handleEdit(row: ContentRow) {
  router.push({ name: 'ContentEdit', query: { id: String(row.id) } })
}

async function handlePreview(row: ContentRow) {
  previewSubtitle.value = row.title || ''
  previewModel.value = null
  previewVisible.value = true
  previewLoading.value = true
  try {
    const res = await getContentDetail(row.id)
    const data = (res as any).data || {}
    previewModel.value = buildPreviewFromDetail(data, row.categoryName)
  } catch (err: any) {
    previewVisible.value = false
    ElMessage.error(err?.message || '加载预览失败')
  } finally {
    previewLoading.value = false
  }
}

function statusLabel(status: ContentStatus): string {
  if (status === 'published') return '已发布'
  if (status === 'unpublished') return '已下架'
  if (status === 'archived') return '已归档'
  return '草稿'
}

function statusTagType(status: ContentStatus): 'success' | 'warning' | 'info' {
  if (status === 'published') return 'success'
  if (status === 'unpublished') return 'warning'
  return 'info'
}

async function handleTogglePublish(row: ContentRow) {
  try {
    if (row.status === 'published') {
      await ElMessageBox.confirm(`确定下架「${row.title}」？`, '下架确认')
      await unpublishContent(row.id)
      ElMessage.success('已下架')
    } else {
      await ElMessageBox.confirm(`确定上架「${row.title}」？`, '上架确认')
      await publishContent(row.id)
      ElMessage.success('已上架')
    }
    fetchList()
  } catch (err: any) {
    if (err === 'cancel' || err === 'close') return
    ElMessage.error(err?.message || '操作失败')
  }
}

async function runBatchStatusChange(action: 'publish' | 'unpublish') {
  const targets =
    action === 'publish'
      ? selectedRows.value.filter((row) => row.status !== 'published')
      : selectedRows.value.filter((row) => row.status === 'published')

  if (!targets.length) {
    ElMessage.warning(action === 'publish' ? '所选内容均已上架' : '所选内容均未上架，无需下架')
    return
  }

  const label = action === 'publish' ? '上架' : '下架'
  try {
    await ElMessageBox.confirm(
      `将对 ${targets.length} 条内容执行批量${label}，是否继续？`,
      `批量${label}确认`,
    )
  } catch {
    return
  }

  batchLoading.value = true
  let ok = 0
  let fail = 0
  try {
    for (const row of targets) {
      try {
        if (action === 'publish') await publishContent(row.id)
        else await unpublishContent(row.id)
        ok += 1
      } catch {
        fail += 1
      }
    }
    if (fail === 0) ElMessage.success(`已成功${label} ${ok} 条`)
    else ElMessage.warning(`${label}完成：成功 ${ok} 条，失败 ${fail} 条`)
    await fetchList()
  } finally {
    batchLoading.value = false
  }
}

function handleBatchPublish() {
  if (!selectedRows.value.length) {
    ElMessage.warning('请先勾选要上架的内容')
    return
  }
  return runBatchStatusChange('publish')
}

function handleBatchUnpublish() {
  if (!selectedRows.value.length) {
    ElMessage.warning('请先勾选要下架的内容')
    return
  }
  return runBatchStatusChange('unpublish')
}

async function handleBatchDelete() {
  const targets = [...selectedRows.value]
  if (!targets.length) {
    ElMessage.warning('请先勾选要删除的内容')
    return
  }

  try {
    await ElMessageBox.confirm(
      `确定删除所选 ${targets.length} 条内容吗？删除后不可恢复。`,
      '批量删除确认',
      {
        type: 'warning',
        confirmButtonText: '确认删除',
        cancelButtonText: '取消',
      },
    )
  } catch {
    return
  }

  batchLoading.value = true
  try {
    const results = await Promise.allSettled(targets.map((row) => deleteContent(row.id)))
    const ok = results.filter((result) => result.status === 'fulfilled').length
    const fail = results.length - ok

    clearSelection()
    await fetchList()
    if (!rows.value.length && pagination.page > 1) {
      pagination.page -= 1
      await fetchList()
    }

    if (fail === 0) ElMessage.success(`已成功删除 ${ok} 条`)
    else ElMessage.warning(`删除完成：成功 ${ok} 条，失败 ${fail} 条`)
  } finally {
    batchLoading.value = false
  }
}

function isRecommended(row: ContentRow): boolean {
  return row.recommended
}

async function toggleRecommend(row: ContentRow) {
  const next = !isRecommended(row)
  const tags = [...(row.tags || [])].filter((t) => t !== RECOMMEND_TAG)
  if (next) tags.push(RECOMMEND_TAG)
  try {
    await updateContent(row.id, {
      title: row.title,
      categoryId: row.categoryId,
      source: row.source || undefined,
      tags,
      sortOrder: next ? -1 : Math.max(row.sortOrder, 0),
    } as any)
    row.recommended = next
    row.tags = tags
    row.sortOrder = next ? -1 : Math.max(row.sortOrder, 0)
    ElMessage.success(next ? '已设为推荐' : '已取消推荐')
  } catch (err: any) {
    ElMessage.error(err?.message || '更新推荐状态失败')
  }
}

async function handleDelete(row: ContentRow) {
  try {
    await ElMessageBox.confirm(`确定删除「${row.title}」？删除后不可恢复。`, '删除确认', { type: 'warning' })
    await deleteContent(row.id)
    ElMessage.success('已删除')
    fetchList()
  } catch (err: any) {
    if (err === 'cancel' || err === 'close') return
    ElMessage.error(err?.message || '删除失败')
  }
}

const categoryModalVisible = ref(false)
const categoryDialogVisible = ref(false)
const categoryDialogMode = ref<'create' | 'edit'>('create')
const categorySubmitting = ref(false)
const categoryEditingId = ref<number | null>(null)
const categoryFormRef = ref<FormInstance>()

const categoryForm = reactive({
  name: '',
  parentId: null as number | null,
})

const categoryRules: FormRules = {
  name: [{ required: true, message: '请输入分类名称', trigger: 'blur' }],
}

function openCategoryDialog(mode: 'create' | 'edit', target: CategoryNode | null) {
  categoryDialogMode.value = mode
  if (mode === 'create') {
    categoryEditingId.value = null
    categoryForm.name = ''
    categoryForm.parentId = target ? target.id : null
  } else {
    if (!target) return
    categoryEditingId.value = target.id
    categoryForm.name = target.name
    categoryForm.parentId = target.parentId
  }
  categoryDialogVisible.value = true
}

function isCategoryPublished(item: CategoryNode) {
  const s = item.status
  return s === 'enabled' || s === '1' || Number(s) === 1
}

async function toggleCategoryPublish(item: CategoryNode) {
  const next = isCategoryPublished(item) ? 0 : 1
  await updateCategory(item.id, {
    name: item.name,
    parentId: item.parentId,
    sortOrder: item.sort,
    status: next,
  } as any)
  ElMessage.success(next === 1 ? `「${item.name}」已发布到顶栏` : `「${item.name}」已取消发布`)
  await fetchCategories()
}

async function submitCategory() {
  const form = categoryFormRef.value
  if (!form) return
  await form.validate()

  categorySubmitting.value = true
  try {
    if (categoryDialogMode.value === 'create') {
      await createCategory({
        name: categoryForm.name.trim(),
        parentId: categoryForm.parentId,
        status: 0,
        sortOrder: 0,
      } as any)
      ElMessage.success('分类已创建（未发布）。点「发布」后会出现在跨境资讯顶栏与发文下拉')
    } else if (categoryEditingId.value) {
      const current = categoryTree.value
        .flatMap((c) => [c, ...c.children])
        .find((c) => c.id === categoryEditingId.value)
      await updateCategory(categoryEditingId.value, {
        name: categoryForm.name.trim(),
        parentId: categoryForm.parentId,
        status: isCategoryPublished(current || ({ status: 'disabled' } as CategoryNode)) ? 1 : 0,
        sortOrder: current?.sort ?? 0,
      } as any)
      ElMessage.success('分类已更新')
    }
    categoryDialogVisible.value = false
    await fetchCategories()
  } finally {
    categorySubmitting.value = false
  }
}

async function removeCategory(item: CategoryNode) {
  await ElMessageBox.confirm(`确定删除分类「${item.name}」？`, '删除确认', { type: 'warning' })
  await deleteCategory(item.id)
  ElMessage.success('分类已删除')
  fetchCategories()
}

onMounted(async () => {
  await fetchCategories()
  await fetchList()
})

onActivated(async () => {
  await fetchCategories()
  await fetchList()
})

watch(
  () => [searchForm.categoryId, searchForm.source, searchForm.type, searchForm.status] as const,
  () => {
    pagination.page = 1
    fetchList()
  }
)

watch(
  () => route.query.refresh,
  async () => {
    await fetchCategories()
    await fetchList()
  }
)
</script>

<style lang="scss" scoped>
.content-page {
  width: 100%;
  max-width: 100%;
  min-width: 0;
  box-sizing: border-box;

  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  }

  .page-title {
    font-size: 22px;
    line-height: 1.2;
    color: #0d1b2e;
    font-weight: 800;
  }

  .page-desc {
    margin-top: 6px;
    color: #6b7b93;
    font-size: 13px;
  }

  .toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
    flex-wrap: wrap;
    min-width: 0;
  }

  .toolbar-input {
    width: 180px;
  }

  .toolbar-select {
    width: 170px;
  }

  .toolbar-spacer {
    flex: 1;
  }

  .sync-result-box {
    margin-top: 12px;
    padding: 14px 16px;
    background: #f5f7fa;
    border-radius: 8px;
    font-size: 13px;
    color: #606266;
    border: 1px solid #e4e7ed;

    &.success {
      background: #f0f9eb;
      border-color: #c2e7b0;
      color: #3d7a2e;
    }

    &.danger {
      background: #fef0f0;
      border-color: #fbc4c4;
      color: #c45656;
    }
  }

  .sync-result-title {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 8px;
  }

  .sync-result-stats {
    display: flex;
    flex-wrap: wrap;
    gap: 12px 18px;
    margin-bottom: 8px;

    b {
      font-size: 16px;
      margin-left: 2px;
    }
  }

  .sync-result-msg {
    line-height: 1.55;
    opacity: 0.9;
  }

  .sync-result-hint {
    margin-top: 10px;
    font-size: 12px;
    opacity: 0.85;
  }

  .sync-progress-box {
    margin-top: 12px;
    padding: 12px 14px;
    background: #f0f7ff;
    border: 1px solid #d6e8ff;
    border-radius: 8px;
  }

  .sync-progress-meta {
    margin-top: 8px;
    font-size: 12px;
    color: #606266;
    line-height: 1.5;
  }

  .sync-failures {
    margin-top: 8px;
    color: #f56c6c;
    line-height: 1.6;
  }

  .table-panel {
    background: #fff;
    border: 1px solid #e4e9f2;
    border-radius: 12px;
    padding: 14px;
    max-width: 100%;
    overflow-x: auto;
    box-sizing: border-box;
  }

  .title-cell {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .title-text {
    font-weight: 700;
    color: #1f2d3d;
  }

  .pagination-wrap {
    margin-top: 14px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 100%;
  }

  .list-metrics {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    padding: 10px 12px;
    background: #f8faff;
    border: 1px solid #e8edf5;
    border-radius: 10px;
  }

  .list-metrics__counts {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  .metric-chip {
    border: 1px solid #dce3ef;
    background: #fff;
    color: #5c6b82;
    border-radius: 999px;
    padding: 4px 12px;
    font-size: 12px;
    line-height: 1.4;
    cursor: pointer;
    transition: all 0.15s ease;

    strong {
      margin-left: 4px;
      color: #1f2d3d;
      font-weight: 700;
    }

    &:hover {
      border-color: #9cb4ff;
      color: #2f5bff;
    }

    &.active {
      border-color: #2f5bff;
      background: #edf2ff;
      color: #2f5bff;
    }
  }

  .metric-chip--published.active {
    border-color: #67c23a;
    background: #f0f9eb;
    color: #67c23a;
  }

  .metric-chip--unpublished.active {
    border-color: #e6a23c;
    background: #fdf6ec;
    color: #e6a23c;
  }

  .list-metrics__summary {
    font-size: 12px;
    color: #6b7b93;
    white-space: nowrap;

    strong {
      color: #1f2d3d;
      font-weight: 700;
    }
  }

  .pagination-wrap :deep(.el-pagination) {
    justify-content: flex-end;
    overflow-x: auto;
    max-width: 100%;
  }

  .category-tip {
    margin-bottom: 12px;
    color: #6b7b93;
    font-size: 12px;
  }

  .category-list {
    max-height: 56vh;
    overflow: auto;
    padding-right: 2px;
  }

  .category-item {
    background: #f8faff;
    border: 1px solid #e4e9f2;
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 8px;
  }

  .category-row,
  .sub-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .category-name {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    color: #1f2d3d;
  }

  .cat-pub-tag {
    font-weight: 500;
  }

  .category-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
  }

  .sub-list {
    margin-left: 24px;
    margin-top: 6px;
    padding-left: 12px;
    border-left: 2px solid #e4e9f2;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .add-root-btn {
    width: 100%;
    margin-top: 8px;
  }

  .preview-dialog-subtitle {
    margin: -8px 0 12px;
    font-size: 13px;
    color: #727a8c;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .preview-dialog-body {
    min-height: 720px;
  }
}
</style>
